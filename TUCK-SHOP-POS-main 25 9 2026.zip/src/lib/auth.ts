import { SignJWT, jwtVerify } from "jose";

const SESSION_COOKIE = "sevesto_session";
const secretKey = new TextEncoder().encode(
  process.env.SESSION_SECRET || "dev-only-insecure-secret-change-me"
);

export type SessionPayload = {
  userId: string;
  name: string;
  role: "cashier" | "manager" | "admin";
};

export async function signSession(payload: SessionPayload): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("12h") // one shift's worth; re-login next shift
    .sign(secretKey);
}

export async function verifySession(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey);
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

export { SESSION_COOKIE };

/** True once a session exists AND its role is manager or admin — used to
 * gate the handful of endpoints a counter cashier shouldn't be able to hit
 * directly (PIN changes, store settings, full-database backup/restore),
 * even though the shared /api middleware only requires "logged in". */
export function isManagerOrAdmin(session: SessionPayload | null): session is SessionPayload {
  return !!session && (session.role === "manager" || session.role === "admin");
}

/** True only for admin — reserved for the single most destructive endpoint
 * in the app (backup restore replaces the entire database). */
export function isAdmin(session: SessionPayload | null): session is SessionPayload {
  return !!session && session.role === "admin";
}
