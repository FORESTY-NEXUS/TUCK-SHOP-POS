import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";
import bcrypt from "bcryptjs";
import { verifySession, isManagerOrAdmin, SESSION_COOKIE } from "@/lib/auth";

// Change PIN: requires the CURRENT pin to be verified before the new one is
// set, so the default 1234 can be replaced on the client's live install.
// Manager/admin only — the shared /api middleware only checks "logged in",
// not role, so a cashier session could otherwise hit this directly.
export async function POST(req: NextRequest) {
  await connectDB();

  const token = req.cookies.get(SESSION_COOKIE)?.value;
  const session = token ? await verifySession(token) : null;
  if (!isManagerOrAdmin(session)) {
    return NextResponse.json({ error: "Only a manager or admin can change the PIN" }, { status: 403 });
  }

  const body = await req.json().catch(() => ({}));
  const { currentPin, newPin } = body;

  if (typeof currentPin !== "string" || currentPin.length === 0) {
    return NextResponse.json({ error: "Current PIN is required" }, { status: 400 });
  }
  if (typeof newPin !== "string" || !/^\d{4,6}$/.test(newPin)) {
    return NextResponse.json({ error: "New PIN must be 4-6 digits" }, { status: 400 });
  }

  // The signed-in user's own record — not just "any" user in the
  // collection, so a shop with several staff PINs can't have the wrong
  // person's PIN silently overwritten.
  const user = await User.findById(session.userId).select("+pinHash");
  if (!user) {
    return NextResponse.json({ error: "Your staff account couldn't be found" }, { status: 404 });
  }

  const valid = await bcrypt.compare(currentPin, user.pinHash);
  if (!valid) {
    return NextResponse.json({ error: "Current PIN is incorrect" }, { status: 401 });
  }

  const hash = await bcrypt.hash(newPin, 10);
  await User.updateOne({ _id: user._id }, { pinHash: hash });

  return NextResponse.json({ success: true });
}
