import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";
import { signSession, SESSION_COOKIE } from "@/lib/auth";

export async function POST(req: NextRequest) {
  await connectDB();
  const { pin } = await req.json();

  if (!pin || typeof pin !== "string") {
    return NextResponse.json({ error: "PIN is required" }, { status: 400 });
  }

  const users = await User.find({ isActive: true }).lean();
  let validUser = null;

  for (const user of users) {
    if (await bcrypt.compare(pin, user.pinHash)) {
      validUser = user;
      break;
    }
  }

  if (validUser) {
    const token = await signSession({
      userId: String(validUser._id),
      name: validUser.name,
      role: validUser.role as "cashier" | "manager" | "admin",
    });
    const res = NextResponse.json({ name: validUser.name, role: validUser.role });
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 12,
    });
    return res;
  }

  return NextResponse.json({ error: "Incorrect PIN" }, { status: 401 });
}
