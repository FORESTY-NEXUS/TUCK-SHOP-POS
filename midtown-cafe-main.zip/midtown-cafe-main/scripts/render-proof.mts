// Static render proofs for Round 3 — renders real components WITHOUT the app
// server (the sandbox can't run Next under its 2GB ceiling): proves the
// Settings sections exist in the rendered output and that the order-creation
// flow renders exactly ONE sidebar. Run: npx tsx scripts/render-proof.mts
import { renderToStaticMarkup } from "react-dom/server";
import React from "react";
import SettingsManager from "../src/components/admin/SettingsManager";
import OrderBuilder from "../src/components/pos/OrderBuilder";

function countOccurrences(haystack: string, needle: string): number {
  let count = 0, idx = 0;
  while ((idx = haystack.indexOf(needle, idx)) !== -1) { count++; idx += needle.length; }
  return count;
}

const settings = {
  _id: "s1", rupeesPerPoint: 100, printerType: "EPSON", paperWidth: 48, autoCut: true,
  autoFillDeliveryAddress: true, storeName: "Sevesto Cafe", storePhone: "0300-1234567",
  storeAddress: "Example Street", speedDial: {},
};
const products = [{ _id: "p1", name: "Sample Product" }];

const settingsHtml = renderToStaticMarkup(
  React.createElement(SettingsManager, { initialSettings: settings as any, initialProducts: products as any })
);
console.log("SETTINGS_HAS_PIN_SECTION:", settingsHtml.includes("Security") && settingsHtml.includes("Change PIN") ? "yes" : "NO");
console.log("SETTINGS_HAS_BACKUP_SECTION:", settingsHtml.includes("Backup &amp; Restore") ? "yes" : "NO");
console.log("SETTINGS_HAS_STORE_BRANDING:", settingsHtml.includes("Store Branding") ? "yes" : "NO");
console.log("SETTINGS_HAS_THERMAL_PRINTER:", settingsHtml.includes("Thermal Printer") ? "yes" : "NO");
console.log("SETTINGS_HAS_SPEED_DIAL:", settingsHtml.includes("Speed Dial") ? "yes" : "NO");

// Order flow sidebar proof — every order-creation step should render ONE sidebar.
const orderBuilderHtml = renderToStaticMarkup(
  React.createElement(OrderBuilder, {
    orderType: "dine_in",
    products: [] as any,
    waiters: [{ _id: "w1", name: "Ahmed (Waiter)" }] as any,
    categories: [] as any,
  })
);
const asides = countOccurrences(orderBuilderHtml, "<aside");
console.log("ORDER_FLOW_ASIDES:", asides);
console.log("ORDER_FLOW_HAS_WAITER_SELECT:", orderBuilderHtml.includes("Set Waiter") ? "yes" : "NO");
console.log("ORDER_FLOW_HAS_GUEST_HINT:", orderBuilderHtml.includes("Guests must be at least 1") ? "yes" : "NO");

console.log("RENDER_PROOFS_DONE");
