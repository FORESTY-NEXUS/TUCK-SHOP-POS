import StaffManager from "@/components/admin/StaffManager";
export const dynamic = "force-dynamic";
import { getStaff } from "@/lib/queries";

export default async function AdminStaffPage() {
  const staff = await getStaff(undefined, true);
  return (
    <div className="h-full w-full">
      <div className="px-6 py-8 w-full">
        <h1 className="text-2xl font-bold text-stone-900 font-brand">Staff</h1>
        <p className="text-sm text-stone-500 mt-0.5 mb-6">Waiters and riders</p>
        <StaffManager initialStaff={staff as any} />
      </div>
    </div>
  );
}
