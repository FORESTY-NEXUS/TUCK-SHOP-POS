import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Order } from "@/models/Order";
import { printKitchenTicket, printReceipt } from "@/lib/print";

export const dynamic = "force-dynamic";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();

  const { id } = await params;
  const body = await req.json();
  const { type } = body as { type?: "kitchen" | "receipt" };

  if (!type || (type !== "kitchen" && type !== "receipt")) {
    return NextResponse.json(
      { error: "type must be 'kitchen' or 'receipt'" },
      { status: 400 }
    );
  }

  const order = await Order.findById(id).lean();
  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  try {
    let result: { success: boolean; error?: string };
    if (type === "kitchen") {
      result = await printKitchenTicket(order);
    } else {
      result = await printReceipt(order);
    }

    if (result.success) {
      return NextResponse.json({ success: true });
    } else {
      return NextResponse.json(
        { success: false, error: result.error || "Print failed" },
        { status: 500 }
      );
    }
  } catch (err: any) {
    console.error(`Print ${type} failed:`, err);
    return NextResponse.json(
      { success: false, error: err.message || "Print failed" },
      { status: 500 }
    );
  }
}