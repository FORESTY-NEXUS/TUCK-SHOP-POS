import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Order, ORDER_STATUSES, PAYMENT_METHODS } from "@/models/Order";
import { Shift } from "@/models/Shift";
import { Settings } from "@/models/Settings";
import { Customer, GUEST_PHONE } from "@/models/Customer";
import { Staff } from "@/models/Staff";
import { Refund } from "@/models/Refund";
import { z } from "zod";

const PatchSchema = z.object({
  status: z.enum(ORDER_STATUSES).optional(),
  riderId: z.string().optional(),
  waiterId: z.string().optional(),
  // Payment: dine-in orders get paid here when the guest leaves;
  // delivery/takeaway are typically paid at creation but can also
  // settle here (e.g. cash-on-delivery collected by the rider).
  pay: z
    .object({
      method: z.enum(PAYMENT_METHODS),
      amount: z.number().min(0),
    })
    .optional(),
  voidReason: z.string().optional(), // voids the whole order
  // Refund: process a full or partial refund
  refund: z
    .object({
      // Full refund: just provide reason
      // Partial item refund: provide items array with orderItemIndex, qtyRefunded
      // Partial custom amount: provide customAmount
      isFullRefund: z.boolean().optional(),
      items: z
        .array(
          z.object({
            orderItemIndex: z.number().int().min(0),
            qtyRefunded: z.number().int().min(1),
          })
        )
        .optional(),
      customAmount: z.number().min(0).optional(),
      refundMethod: z.enum(PAYMENT_METHODS).optional(), // defaults to original paymentMethod
      reason: z.string().min(1, "Refund reason is required"),
    })
    .optional(),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();
  const { id } = await params;

  const body = await req.json();
  const parsed = PatchSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  const order = await Order.findById(id);
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });

  // Delivery rule (server-enforced): a real, non-zero delivery charge must be
  // set before the order can be marked ready / dispatched / completed. A
  // direct API call cannot skip this.
  if (
    order.type === "delivery" &&
    data.status &&
    ["ready", "dispatched", "completed"].includes(data.status) &&
    !(order.deliveryCharges > 0)
  ) {
    return NextResponse.json(
      { error: "Set a delivery charge before marking this order ready/dispatched/completed" },
      { status: 400 }
    );
  }

  if (data.status) order.status = data.status;
  if (data.riderId) order.rider = data.riderId as unknown as typeof order.rider;
  if (data.waiterId) order.waiter = data.waiterId as unknown as typeof order.waiter;

  if (data.pay) {
    const openShift = await Shift.findOne({ isOpen: true });
    if (!openShift) {
      return NextResponse.json(
        { error: "No shift is open — start a shift before taking payment" },
        { status: 409 }
      );
    }
    order.isPaid = true;
    order.paymentMethod = data.pay.method;
    order.paidAmount = data.pay.amount;
    order.paidAt = new Date();
    order.status = "completed";
    order.shift = openShift._id;

    // Award loyalty points if order has a linked customer (and it's not the shared Guest record)
    if (order.customer) {
      // Check if customer is the shared Guest walk-in record — skip points for Guest
      const linkedCustomer = await Customer.findById(order.customer).lean();
      if (linkedCustomer && linkedCustomer.phone !== GUEST_PHONE) {
        // Fetch settings to get earn rate
        const settings = await Settings.findOne().lean();
        const rupeesPerPoint = settings?.rupeesPerPoint ?? 100;

        // Use order.total (includes delivery charges, after discount)
        // Round down: no fractional points
        const pointsEarned = Math.floor(order.total / rupeesPerPoint);

        if (pointsEarned > 0) {
          // Atomic increment to avoid race conditions
          await Customer.findByIdAndUpdate(order.customer, {
            $inc: { loyaltyPoints: pointsEarned },
          });
        }

        // Save delivery address to customer's lastAddress for future convenience
        // Only for delivery orders that have a deliveryAddress
        if (order.type === "delivery" && order.deliveryAddress) {
          await Customer.findByIdAndUpdate(order.customer, {
            $set: { lastAddress: order.deliveryAddress },
          });
        }
      }
    }
  }

  if (data.voidReason) {
    if (order.isPaid) {
      return NextResponse.json(
        { error: "Cannot void a paid order — use a refund flow instead" },
        { status: 409 }
      );
    }
    if (!data.voidReason.trim()) {
      return NextResponse.json(
        { error: "Void reason is required" },
        { status: 400 }
      );
    }
    order.status = "cancelled";
    order.voidReason = data.voidReason.trim();
  }

  if (data.refund) {
    // Refund can only be processed on paid orders
    if (!order.isPaid) {
      return NextResponse.json(
        { error: "Cannot refund an unpaid order" },
        { status: 409 }
      );
    }
    if (order.status === "cancelled" || order.status === "refunded") {
      return NextResponse.json(
        { error: "Order is already cancelled or fully refunded" },
        { status: 409 }
      );
    }

    // Validate refund reason
    const reason = data.refund.reason.trim();
    if (!reason) {
      return NextResponse.json(
        { error: "Refund reason is required" },
        { status: 400 }
      );
    }

    // Find the open shift for the refund (refunds are tracked against current shift)
    const openShift = await Shift.findOne({ isOpen: true });
    if (!openShift) {
      return NextResponse.json(
        { error: "No shift is open — start a shift before processing refund" },
        { status: 409 }
      );
    }

    // Get staff from auth (for now, we'll use a default staff or require staffId)
    // In a real scenario, you'd get this from the authenticated user
    // For now, find any staff or create a default
    let staff = await Staff.findOne().lean();
    if (!staff) {
      // Never block a refund because no staff record exists: create a single
      // hidden "System" fallback (isActive:false keeps it out of the
      // Waiter/Rider selection lists) so the refund keeps its audit trail.
      staff = (await Staff.create({ name: "System", role: "waiter", isActive: false })).toObject();
    }

    // Fetch settings for loyalty points calculation
    const settings = await Settings.findOne().lean();
    const rupeesPerPoint = settings?.rupeesPerPoint ?? 100;

    // Determine refund amount and items
    let refundAmount = 0;
    let isFullRefund = data.refund.isFullRefund === true;
    const refundItems: Array<{
      orderItemIndex: number;
      productName: string;
      price: number;
      qty: number;
      lineDiscountPercent?: number;
      qtyRefunded: number;
      amount: number;
    }> = [];

    if (isFullRefund) {
      // Full refund: refund the remaining paid balance. On partially-refunded
      // orders, this completes the refund instead of attempting to refund the
      // original paid amount again.
      refundAmount = (order.paidAmount ?? 0) - (order.refundedAmount ?? 0);
      // Mark all items as refunded
      order.items.forEach((item: any, index: number) => {
        if (!item.isVoided) {
          const lineTotal = item.price * item.qty * (1 - (item.lineDiscountPercent ?? 0) / 100);
          refundItems.push({
            orderItemIndex: index,
            productName: item.name,
            price: item.price,
            qty: item.qty,
            lineDiscountPercent: item.lineDiscountPercent ?? 0,
            qtyRefunded: item.qty,
            amount: lineTotal,
          });
        }
      });
    } else if (data.refund.items && data.refund.items.length > 0) {
      // Partial item refund
      for (const ri of data.refund.items) {
        const item = order.items[ri.orderItemIndex];
        if (!item) {
          return NextResponse.json(
            { error: `Invalid item index: ${ri.orderItemIndex}` },
            { status: 400 }
          );
        }
        if (item.isVoided) {
          return NextResponse.json(
            { error: `Item ${ri.orderItemIndex} is already voided` },
            { status: 400 }
          );
        }
        // Check if refund qty exceeds what's available
        const alreadyRefunded = item.qty - (item.qtyRefunded ?? 0); // We'll track this on the item
        // For now, we'll track qtyRefunded on the order item
        const availableQty = item.qty - (item.qtyRefunded ?? 0);
        if (ri.qtyRefunded > availableQty) {
          return NextResponse.json(
            { error: `Cannot refund ${ri.qtyRefunded} of item ${ri.orderItemIndex}, only ${availableQty} available` },
            { status: 400 }
          );
        }
        const lineTotal = item.price * ri.qtyRefunded * (1 - (item.lineDiscountPercent ?? 0) / 100);
        refundAmount += lineTotal;
        refundItems.push({
          orderItemIndex: ri.orderItemIndex,
          productName: item.name,
          price: item.price,
          qty: item.qty,
          lineDiscountPercent: item.lineDiscountPercent ?? 0,
          qtyRefunded: ri.qtyRefunded,
          amount: lineTotal,
        });
      }
    } else if (data.refund.customAmount !== undefined && data.refund.customAmount > 0) {
      // Custom partial amount refund
      refundAmount = data.refund.customAmount;
      if (refundAmount > (order.paidAmount ?? 0) - (order.refundedAmount ?? 0)) {
        return NextResponse.json(
          { error: `Refund amount exceeds available balance` },
          { status: 400 }
        );
      }
      // No specific items tracked for custom amount
    } else {
      return NextResponse.json(
        { error: "Refund must specify isFullRefund, items, or customAmount" },
        { status: 400 }
      );
    }

    if (refundAmount <= 0) {
      return NextResponse.json(
        { error: "Refund amount must be greater than 0" },
        { status: 400 }
      );
    }

    // Check if total refunded would exceed paid amount
    const totalRefundedAfter = (order.refundedAmount ?? 0) + refundAmount;
    if (totalRefundedAfter > (order.paidAmount ?? 0)) {
      return NextResponse.json(
        { error: `Total refunded amount would exceed paid amount` },
        { status: 400 }
      );
    }

    // Determine refund method (defaults to original payment method)
    const refundMethod = data.refund.refundMethod ?? order.paymentMethod ?? "cash";

    // Create refund record
    const refund = await Refund.create({
      order: order._id,
      shift: openShift._id,
      staff: staff._id,
      amount: refundAmount,
      refundMethod,
      isFullRefund,
      items: refundItems,
      customAmount: data.refund.customAmount,
      reason,
    });

    // Update order with refund info
    order.refundedAmount = totalRefundedAfter;
    if (isFullRefund || totalRefundedAfter >= (order.paidAmount ?? 0)) {
      order.status = "refunded";
      order.isRefunded = true;
    } else {
      order.status = "partially_refunded";
    }

    // Track refunded qty on order items
    for (const ri of refundItems) {
      const item = order.items[ri.orderItemIndex];
      if (item) {
        item.qtyRefunded = (item.qtyRefunded ?? 0) + ri.qtyRefunded;
      }
    }

    // Reverse loyalty points proportionally
    if (order.customer && refundAmount > 0) {
      // Calculate points to reverse based on refund proportion
      const totalPaid = order.paidAmount ?? 0;
      const pointsOriginallyEarned = Math.floor(totalPaid / rupeesPerPoint);
      if (pointsOriginallyEarned > 0) {
        // Proportional reversal
        const pointsToReverse = Math.floor((refundAmount / totalPaid) * pointsOriginallyEarned);
        if (pointsToReverse > 0) {
          await Customer.findByIdAndUpdate(order.customer, {
            $inc: { loyaltyPoints: -pointsToReverse },
          });
        }
      }
    }

    await order.save();

    return NextResponse.json({ order, refund });
  }

  await order.save();
  return NextResponse.json(order);
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();
  const { id } = await params;
  const order = await Order.findById(id)
    .populate("customer", "name phone loyaltyPoints")
    .populate("waiter", "name")
    .populate("rider", "name")
    .lean();
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  return NextResponse.json(order);
}
