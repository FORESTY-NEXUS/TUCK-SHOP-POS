import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Order, ORDER_TYPES, OrderType } from "@/models/Order";
import { Product } from "@/models/Product";
import { nextSequence } from "@/models/Counter";
import { z } from "zod";
import { printKitchenTicket } from "@/lib/print";
// Import Customer to ensure model is registered before populate()
import "@/models/Customer";

// GET /api/orders?type=delivery — powers the Cockpit board.
// Not statically cached: this is "live" data cashiers act on immediately.
export async function GET(req: NextRequest) {
  await connectDB();
  const type = req.nextUrl.searchParams.get("type") as OrderType | null;

  const filter: Record<string, unknown> = { status: { $nin: ["completed", "cancelled"] } };
  if (type && ORDER_TYPES.includes(type)) filter.type = type;

  const orders = await Order.find(filter)
    .sort({ createdAt: -1 })
    .populate("customer", "name phone loyaltyPoints")
    .populate("waiter", "name")
    .populate("rider", "name")
    .lean();

  return NextResponse.json(orders);
}

const CartItemSchema = z.object({
  productId: z.string(),
  qty: z.number().int().min(1),
  lineDiscountPercent: z.number().min(0).max(100).optional(),
  // Variants: the client only sends the INDEX of the chosen variant.
  // The server resolves the variant's name/price from the product itself so
  // a direct API caller can never invent prices.
  variantIndex: z.number().int().min(0).optional(),
});

// This is the "batch operation" endpoint: the client builds the whole
// cart locally (tap burger, set qty 3, tap fries, ...) with ZERO network
// calls in between, then submits everything here in a single request
// when the order is confirmed. This is what makes order entry fast.
const CreateOrderSchema = z.object({
  type: z.enum(ORDER_TYPES),
  items: z.array(CartItemSchema).min(1),
  table: z.string().optional(),
  guests: z.number().int().optional(),
  customerId: z.string().optional(),
  deliveryAddress: z.string().optional(),
  deliveryCharges: z.number().min(0).optional(),
  waiterId: z.string().optional(),
  discountPercent: z.number().min(0).max(100).optional(),
  note: z.string().optional(),
}).refine(
  (data) => {
    // Dine-In / Takeaway / Delivery ALL require a linked customer. Walk-in
    // guests link to the shared "Guest" record (phone 0000000000), which the
    // client creates before submitting. This is enforced server-side so a
    // direct API call can never create an order with no customer — loyalty,
    // auto-fill and refund bookkeeping all depend on the link.
    return data.customerId !== undefined && data.customerId !== null && data.customerId !== "";
  },
  { message: "customerId is required — link a customer (or the shared Guest record) before creating an order", path: ["customerId"] }
);

export async function POST(req: NextRequest) {
  await connectDB();

  const body = await req.json();
  const parsed = CreateOrderSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  const data = parsed.data;

  // Validate customerId exists if provided (for delivery/takeaway)
  if (data.customerId) {
    const { Customer } = await import("@/models/Customer");
    const customer = await Customer.findById(data.customerId).lean();
    if (!customer) {
      return NextResponse.json({ error: "Customer not found" }, { status: 400 });
    }
  }

  // Resolve products once, in one query, and snapshot name/price onto the
  // order so later menu price changes never retroactively alter past orders.
  const productIds = data.items.map((i) => i.productId);
  const products = await Product.find({ _id: { $in: productIds } }).lean();
  const productMap = new Map(products.map((p) => [String(p._id), p]));

  let items: Array<{ product: unknown; name: string; price: number; qty: number; lineDiscountPercent: number }>;
  try {
    items = data.items.map((i) => {
      const product = productMap.get(i.productId);
      if (!product) throw new Error(`Unknown product: ${i.productId}`);

      let name = product.name;
      let price = product.price;

      // Variant selection: server-side price resolution (never trust the client).
      if (i.variantIndex != null) {
        const variants = (product as any).variants || [];
        const variant = variants[i.variantIndex];
        if (!variant) {
          throw new Error(`Invalid variant for product: ${product.name}`);
        }
        name = `${product.name} (${variant.name})`;
        price = Number(variant.price);
      }

      return {
        product: product._id,
        name,
        price,
        qty: i.qty,
        lineDiscountPercent: i.lineDiscountPercent ?? 0,
      };
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "Invalid order items" }, { status: 400 });
  }

  const subtotal = items.reduce((sum, i) => {
    const lineTotal = i.price * i.qty * (1 - (i.lineDiscountPercent ?? 0) / 100);
    return sum + lineTotal;
  }, 0);

  const deliveryCharges = data.deliveryCharges ?? 0;
  const discountAmount = subtotal * ((data.discountPercent ?? 0) / 100);
  const total = subtotal - discountAmount + deliveryCharges;

  const seq = await nextSequence("order");
  const prefix = { dine_in: "DI", takeaway: "TA", delivery: "DL" }[data.type];
  const orderNumber = `${prefix}-${String(seq).padStart(5, "0")}`;

  const order = await Order.create({
    orderNumber,
    type: data.type,
    table: data.table,
    guests: data.guests,
    customer: data.customerId || undefined,
    deliveryAddress: data.deliveryAddress,
    deliveryCharges,
    waiter: data.waiterId || undefined,
    items,
    discountPercent: data.discountPercent ?? 0,
    discountAmount,
    note: data.note,
    subtotal,
    total,
    status: "preparing",
    // Kitchen ticket prints immediately for every order type on confirmation.
    confirmedAt: new Date(),
    kitchenTicketPrinted: true,
  });

  // Kitchen ticket print — the order is already saved above. A printer that
  // is unreachable, unconfigured, or throws MUST never fail the order or
  // cause a duplicate on client retry, so the whole print is isolated.
  let printResult: { success: boolean; error?: string } = { success: false, error: "Print not attempted" };
  try {
    printResult = await printKitchenTicket(order as any);
    if (!printResult.success) {
      console.error("Kitchen ticket print failed:", printResult.error);
    }
  } catch (err: any) {
    printResult = { success: false, error: err?.message || "Print failed" };
    console.error("Kitchen ticket print threw:", err);
  }

  return NextResponse.json({ ...order.toJSON(), printResult }, { status: 201 });
}
