import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Order } from "@/models/Order";
import { Refund } from "@/models/Refund";
// Ensure Customer/Staff schemas are registered in Mongoose (required for .populate())
import { Customer } from "@/models/Customer";
import { Staff } from "@/models/Staff";
import { sanitizeForClient } from "@/lib/serialize";

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const _models = [Customer, Staff]; // keep Mongoose schema registrations alive in Turbopack

// GET /api/orders/history — server-side paginated order history for admin page
export async function GET(req: NextRequest) {
  await connectDB();

  const PAGE_SIZE = 50;

  const page = Math.max(1, parseInt(req.nextUrl.searchParams.get("page") || "1", 10));
  const range = req.nextUrl.searchParams.get("range") || "all";
  const type = req.nextUrl.searchParams.get("type") || "all";
  const status = req.nextUrl.searchParams.get("status") || "all";
  const customerId = req.nextUrl.searchParams.get("customerId");
  const search = req.nextUrl.searchParams.get("search") || "";
  const customStart = req.nextUrl.searchParams.get("start");
  const customEnd = req.nextUrl.searchParams.get("end");

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const todayEnd = new Date(todayStart.getTime() + 24 * 60 * 60 * 1000 - 1);

  let start: Date;
  let end: Date;

  switch (range) {
    case "today": {
      start = todayStart;
      end = todayEnd;
      break;
    }
    case "yesterday": {
      const yStart = new Date(todayStart.getTime() - 24 * 60 * 60 * 1000);
      const yEnd = new Date(yStart.getTime() + 24 * 60 * 60 * 1000 - 1);
      start = yStart;
      end = yEnd;
      break;
    }
    case "this_week": {
      const dayOfWeek = now.getDay();
      const weekStart = new Date(todayStart.getTime() - dayOfWeek * 24 * 60 * 60 * 1000);
      const weekEnd = new Date(weekStart.getTime() + 7 * 24 * 60 * 60 * 1000 - 1);
      start = weekStart;
      end = weekEnd;
      break;
    }
    case "this_month": {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1, 23, 59, 59, 999);
      start = monthStart;
      end = monthEnd;
      break;
    }
    case "all": {
      const epochStart = new Date("2020-01-01");
      start = epochStart;
      end = todayEnd;
      break;
    }
    case "custom": {
      if (!customStart || !customEnd) {
        start = todayStart;
        end = todayEnd;
      } else {
        start = new Date(customStart);
        start.setHours(0, 0, 0, 0);
        end = new Date(customEnd);
        end.setHours(23, 59, 59, 999);
      }
      break;
    }
    default: {
      start = todayStart;
      end = todayEnd;
    }
  }

  const filter: Record<string, unknown> = {
    createdAt: { $gte: start, $lte: end },
  };

  if (type && type !== "all") {
    filter.type = type;
  }
  if (status && status !== "all") {
    filter.status = status;
  }
  if (customerId) {
    filter.customer = customerId;
  }
  if (search) {
    const re = { $regex: search, $options: "i" };
    filter.$or = [{ orderNumber: re }, { deliveryAddress: re }, { note: re }];
  }

  // Get total count for pagination
  const totalCount = await Order.countDocuments(filter);

  // Fetch orders with pagination
  const orders = await Order.find(filter)
    .sort({ createdAt: -1 })
    .skip((page - 1) * PAGE_SIZE)
    .limit(PAGE_SIZE)
    .populate("customer", "name phone loyaltyPoints")
    .populate("waiter", "name")
    .populate("rider", "name")
    .lean();

  // Get refunds for these orders to determine refund status
  const orderIds = orders.map((o) => o._id);
  const refunds = await Refund.find({ order: { $in: orderIds } }).lean();
  const refundMap = new Map(refunds.map((r) => [String(r.order), r]));

  const data = {
    orders: orders.map((o) => ({
      ...o,
      refund: refundMap.get(String(o._id)) || null,
    })),
    totalCount,
    page,
    totalPages: Math.ceil(totalCount / PAGE_SIZE),
    pageSize: PAGE_SIZE,
  };

  return NextResponse.json(sanitizeForClient(data));
}