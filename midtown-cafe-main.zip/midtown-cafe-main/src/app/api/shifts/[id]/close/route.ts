import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Shift } from "@/models/Shift";
import { Order } from "@/models/Order";
import { Refund } from "@/models/Refund";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();
  const { id } = await params;
  const body = await req.json(); // { actualCash: number }

  const shift = await Shift.findById(id);
  if (!shift) return NextResponse.json({ error: "Shift not found" }, { status: 404 });
  if (!shift.isOpen) return NextResponse.json({ error: "Shift already closed" }, { status: 409 });

  // Expected cash = opening float + all CASH payments collected during
  // this shift - CASH refunds paid out during this shift.
  // Non-cash methods (EasyPaisa/JazzCash/card/bank) don't
  // affect the physical cash drawer, so they're excluded from this sum
  // but still show up in the payment-method breakdown below.
  const cashOrders = await Order.find({ shift: shift._id, paymentMethod: "cash" }).lean();
  const cashCollected = cashOrders.reduce((sum, o) => sum + (o.paidAmount ?? 0), 0);

  // Get cash refunds for this shift
  const cashRefunds = await Refund.find({ shift: shift._id, refundMethod: "cash" }).lean();
  const cashRefunded = cashRefunds.reduce((sum, r) => sum + (r.amount ?? 0), 0);

  const expectedCash = shift.openingBalance + cashCollected - cashRefunded;

  const allOrders = await Order.find({ shift: shift._id }).lean();
  const allRefunds = await Refund.find({ shift: shift._id }).lean();

  // By method breakdown: NET amounts (payments - refunds)
  const byMethod: Record<string, { gross: number; refunded: number; net: number }> = {};

  // Add payments
  for (const o of allOrders) {
    if (o.paymentMethod) {
      if (!byMethod[o.paymentMethod]) {
        byMethod[o.paymentMethod] = { gross: 0, refunded: 0, net: 0 };
      }
      byMethod[o.paymentMethod].gross += o.paidAmount ?? 0;
    }
  }

  // Subtract refunds
  for (const r of allRefunds) {
    if (r.refundMethod) {
      if (!byMethod[r.refundMethod]) {
        byMethod[r.refundMethod] = { gross: 0, refunded: 0, net: 0 };
      }
      byMethod[r.refundMethod].refunded += r.amount ?? 0;
    }
  }

  // Calculate net
  for (const method of Object.keys(byMethod)) {
    byMethod[method].net = byMethod[method].gross - byMethod[method].refunded;
  }

  shift.closedAt = new Date();
  shift.closingBalance = body.actualCash;
  shift.expectedCash = expectedCash;
  shift.difference = body.actualCash - expectedCash;
  shift.isOpen = false;
  shift.byMethod = byMethod;
  shift.orderCount = allOrders.length;
  shift.refundCount = allRefunds.length;
  await shift.save();

  return NextResponse.json({
    shift,
    summary: {
      cashCollected,
      cashRefunded,
      expectedCash,
      actualCash: body.actualCash,
      difference: shift.difference,
      byMethod,
      orderCount: allOrders.length,
      refundCount: allRefunds.length,
    },
  });
}
