import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";
import { signSession, SESSION_COOKIE } from "@/lib/auth";

export async function POST(req: NextRequest) {
  await connectDB();
  const { pin } = await req.json();

  if (!pin || typeof pin !== "string") {
    return NextResponse.json({ error: "PIN is required" }, { status: 400 });
  }

  // Staff counts are small (a handful of active users per cafe), so
  // comparing against each hash is cheap and avoids storing plaintext
  // or reversibly-encrypted PINs.
  const users = await User.find({ isActive: true }).lean();
  for (const user of users) {
    const match = await bcrypt.compare(pin, user.pinHash);
    if (match) {
      const token = await signSession({
        userId: String(user._id),
        name: user.name,
        role: user.role as "cashier" | "manager" | "admin",
      });
      const res = NextResponse.json({ name: user.name, role: user.role });
      res.cookies.set(SESSION_COOKIE, token, {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        maxAge: 60 * 60 * 12,
      });
      return res;
    }
  }

  return NextResponse.json({ error: "Incorrect PIN" }, { status: 401 });
}
