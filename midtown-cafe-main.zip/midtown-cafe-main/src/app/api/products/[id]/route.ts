import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Product } from "@/models/Product";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();
  const { id } = await params;
  const product = await Product.findById(id).populate("category", "name sortOrder").lean();
  if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(product);
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();
  const { id } = await params;
  const body = await req.json();

  const update: Record<string, unknown> = { ...body };

  // Variant edits are sanitized server-side; toggling hasVariants off clears them.
  if (body.hasVariants === true) {
    const variants = Array.isArray(body.variants)
      ? body.variants
          .filter(
            (v: any) =>
              v && typeof v.name === "string" && v.name.trim() && typeof v.price === "number" && v.price >= 0
          )
          .map((v: any) => ({ name: v.name.trim(), price: Number(v.price) }))
      : [];
    if (variants.length === 0) {
      return NextResponse.json(
        { error: "hasVariants requires at least one named variant" },
        { status: 400 }
      );
    }
    update.variants = variants;
    update.price = 0; // base price is meaningless for variant products
  } else if (Array.isArray(body.variants)) {
    update.variants = [];
  }

  const product = await Product.findByIdAndUpdate(id, update, { new: true });
  if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const populated = await Product.findById(product._id).populate("category", "name sortOrder").lean();
  return NextResponse.json(populated);
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  await connectDB();
  const { id } = await params;

  // "Remove" = permanent delete. Past orders are unaffected: every order line
  // snapshots its own name/price at order time, so history stays intact even
  // though the product document is gone.
  const product = await Product.findByIdAndDelete(id);
  if (!product) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ success: true });
}
