import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Product } from "@/models/Product";
import { Category } from "@/models/Category";
import { Types } from "mongoose";

// Menu data changes rarely (someone edits it in admin, not every order),
// so this is safe to cache aggressively and revalidate on demand.
// `dynamic` keeps it off the build-time static export path (this route
// needs a live DB connection, which isn't available during `next build`);
// `revalidate` still controls the runtime cache lifetime.
export const dynamic = "force-dynamic";
export const revalidate = 60; // seconds

export async function GET(req: NextRequest) {
  await connectDB();
  // Admin needs the full list (incl. unavailable); the POS order screen only
  // wants sellable items. Default = sellable only.
  const includeUnavailable = req.nextUrl.searchParams.get("all") === "1";
  const filter = includeUnavailable ? {} : { isAvailable: true };
  const products = await Product.find(filter)
    .populate("category", "name sortOrder")
    .sort({ name: 1 })
    .lean();
  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  await connectDB();
  const body = await req.json();
  if (!body.name || body.price == null || !body.category) {
    return NextResponse.json({ error: "name, price, category are required" }, { status: 400 });
  }

  let categoryId = body.category;

  // If category is a string name (not ObjectId), find or create the Category document
  if (typeof categoryId === "string" && !Types.ObjectId.isValid(categoryId)) {
    let cat = await Category.findOne({ name: categoryId });
    if (!cat) {
      // Create new category with next sortOrder
      const lastCat = await Category.findOne().sort({ sortOrder: -1 }).lean();
      const nextSortOrder = (lastCat?.sortOrder ?? -1) + 1;
      cat = await Category.create({ name: categoryId, sortOrder: nextSortOrder });
    }
    categoryId = cat._id;
  }

  // Variants are validated + sanitized server-side; when hasVariants is set
  // the base price is forced to 0 (the order screen resolves prices from the
  // chosen variant) so a client can never smuggle a bogus base price in.
  const hasVariants = body.hasVariants === true;
  const variants = Array.isArray(body.variants)
    ? body.variants
        .filter(
          (v: any) =>
            v && typeof v.name === "string" && v.name.trim() && typeof v.price === "number" && v.price >= 0
        )
        .map((v: any) => ({ name: v.name.trim(), price: Number(v.price) }))
    : [];
  if (hasVariants && variants.length === 0) {
    return NextResponse.json(
      { error: "hasVariants requires at least one named variant" },
      { status: 400 }
    );
  }

  const product = await Product.create({
    name: body.name,
    price: hasVariants ? 0 : body.price,
    category: categoryId,
    cost: body.cost ?? 0,
    hasVariants,
    variants,
  });

  const populated = await Product.findById(product._id).populate("category", "name sortOrder").lean();
  return NextResponse.json(populated, { status: 201 });
}
