import CockpitBoard from "@/components/pos/CockpitBoard";
export const dynamic = "force-dynamic";
import { getActiveOrders } from "@/lib/orders";
import AppLayout from "@/components/Layout/AppLayout";

export default async function PosCockpitPage() {
  const orders = await getActiveOrders();

  return (
    <AppLayout>
      <main className="h-full w-full flex flex-col bg-stone-100">
        <CockpitBoard initialOrders={orders as any[]} />
      </main>
    </AppLayout>
  );
}
