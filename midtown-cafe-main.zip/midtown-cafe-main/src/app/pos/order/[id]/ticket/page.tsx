import { getOrderById, getSettings } from "@/lib/queries";
import { notFound } from "next/navigation";

// Browser-renderable, brand-styled receipt (used by staff for a quick visual
// check or a browser-print copy). The ESC/POS receipt prints separately via
// the printer API — this page renders the same content with the brand
// typeface so "Sevesto" shows in Manrope, which thermal hardware can't do.
export default async function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order: any = await getOrderById(id);
  if (!order) notFound();
  const settings: any = await getSettings();

  const storeName = settings.storeName || "Sevesto Cafe";
  const typeLabels: Record<string, string> = { dine_in: "Dine In", takeaway: "Takeaway", delivery: "Delivery" };
  const methodLabels: Record<string, string> = { cash: "Cash", easypaisa: "EasyPaisa", jazzcash: "JazzCash", card: "Card", bank: "Bank Transfer" };
  const isGuest = order.customer?.phone === "0000000000" || !order.customer;

  const lineTotal = (item: any) => item.price * item.qty * (1 - (item.lineDiscountPercent || 0) / 100);

  return (
    <main className="min-h-screen bg-stone-100 py-10 px-4 font-sans">
      <div className="max-w-sm mx-auto bg-white rounded-2xl shadow-sm border border-stone-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 border-b border-dashed border-stone-200 text-center">
          {settings.receiptLogo && (
            <img src={settings.receiptLogo} alt={storeName} className="h-12 mx-auto object-contain mb-2" />
          )}
          <h1 className="text-xl font-bold text-stone-900 font-brand">{storeName}</h1>
          {settings.storeAddress && <p className="text-xs text-stone-500 mt-0.5">{settings.storeAddress}</p>}
          {settings.storePhone && (
            <p className="text-xs text-stone-500 mt-0.5">
              {settings.storePhone} ·{" "}
              <a href={`https://wa.me/${settings.storePhone.replace(/\D/g, "")}`} className="text-brand-700 hover:underline">
                WhatsApp
              </a>
            </p>
          )}
          <p className="text-[11px] tracking-widest uppercase text-stone-400 mt-1">Customer Receipt</p>
        </div>

        {/* Meta */}
        <div className="px-6 py-4 border-b border-dashed border-stone-200 text-xs space-y-0.5 text-stone-600">
          <div className="flex justify-between">
            <span>Order</span>
            <span className="font-semibold text-stone-900 tabular">{order.orderNumber}</span>
          </div>
          <div className="flex justify-between">
            <span>Type</span>
            <span className="font-medium capitalize">{typeLabels[order.type] || order.type}</span>
          </div>
          {order.table && <div className="flex justify-between"><span>Table</span><span className="tabular">{order.table}</span></div>}
          {order.guests && <div className="flex justify-between"><span>Guests</span><span className="tabular">{order.guests}</span></div>}
          {!isGuest && (
            <>
              <div className="flex justify-between"><span>Customer</span><span>{order.customer.name}</span></div>
              <div className="flex justify-between"><span>Phone</span><span className="tabular">{order.customer.phone}</span></div>
            </>
          )}
          {order.type === "delivery" && order.deliveryAddress && (
            <div><span className="text-stone-500">Deliver to: </span><span>{order.deliveryAddress}</span></div>
          )}
          <div className="flex justify-between">
            <span>Date</span>
            <span className="tabular">{new Date(order.createdAt).toLocaleString()}</span>
          </div>
        </div>

        {/* Items */}
        <div className="px-6 py-4 border-b border-dashed border-stone-200">
          <div className="space-y-2.5">
            {(order.items || []).map((item: any, i: number) => (
              <div key={i} className="flex justify-between gap-3 text-sm">
                <div className="min-w-0">
                  <div className="font-medium text-stone-900">
                    {item.qty > 1 ? <span className="text-brand-700 font-semibold">{item.qty}× </span> : null}
                    {item.name}
                  </div>
                  {item.lineDiscountPercent > 0 && (
                    <div className="text-xs text-green-700">−{item.lineDiscountPercent}% off</div>
                  )}
                </div>
                <div className="text-right font-medium text-stone-900 tabular shrink-0">
                  Rs. {lineTotal(item).toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Totals */}
        <div className="px-6 py-4 border-b border-dashed border-stone-200 text-sm space-y-1">
          <div className="flex justify-between text-stone-600"><span>Subtotal</span><span className="tabular">Rs. {Number(order.subtotal).toFixed(2)}</span></div>
          {(order.discountAmount ?? 0) > 0 && (
            <div className="flex justify-between text-green-700"><span>Discount ({order.discountPercent}%)</span><span className="tabular">− Rs. {Number(order.discountAmount).toFixed(2)}</span></div>
          )}
          {(order.deliveryCharges ?? 0) > 0 && (
            <div className="flex justify-between text-stone-600"><span>Delivery</span><span className="tabular">Rs. {Number(order.deliveryCharges).toFixed(2)}</span></div>
          )}
          <div className="flex justify-between font-bold text-stone-900 text-lg pt-2">
            <span>Total</span>
            <span className="tabular">Rs. {Number(order.total).toFixed(2)}</span>
          </div>
          {order.isPaid && (
            <div className="flex justify-between text-stone-500 text-xs pt-1">
              <span>Payment</span>
              <span className="tabular">{methodLabels[order.paymentMethod] || order.paymentMethod} · Rs. {Number(order.paidAmount).toFixed(2)}</span>
            </div>
          )}
          {(order.refundedAmount ?? 0) > 0 && (
            <div className="flex justify-between text-red-600 text-xs"><span>Refunded</span><span className="tabular">Rs. {Number(order.refundedAmount).toFixed(2)}</span></div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-5 text-center space-y-1">
          <p className="text-xs text-stone-500 leading-relaxed">
            Fresh food, warm service — that&apos;s what this counter is about. We cook every order the way we&apos;d
            serve it to our own family. See you soon.
          </p>
          <div className="pt-3 text-xs text-stone-400">
            Powered by <span className="font-brand font-bold text-stone-700">Sevesto POS</span> made by{" "}
            <a href="https://foresty-nexus.vercel.app" target="_blank" rel="noopener noreferrer" className="text-brand-700 hover:underline">
              foresty
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}
