import PaymentPanel from "@/components/pos/PaymentPanel";
export const dynamic = "force-dynamic";
import { getOrderById } from "@/lib/queries";
import { notFound } from "next/navigation";

export default async function PayPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await getOrderById(id);
  if (!order || (order as any).isPaid) notFound();

  return (
    <main className="h-screen flex flex-col bg-stone-100">
      <PaymentPanel
        order={{
          _id: (order as any)._id,
          orderNumber: (order as any).orderNumber,
          total: (order as any).total,
        }}
      />
    </main>
  );
}
