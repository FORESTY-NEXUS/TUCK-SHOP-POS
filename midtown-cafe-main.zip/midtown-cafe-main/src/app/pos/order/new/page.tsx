import OrderBuilder from "@/components/pos/OrderBuilder";
export const dynamic = "force-dynamic";
import { getProducts, getCategories, getStaff, getSettings } from "@/lib/queries";

export default async function NewOrderPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string }>;
}) {
  const { type } = await searchParams;

  const [products, categories, waiters, settings] = await Promise.all([
    getProducts(),
    getCategories(),
    getStaff("waiter"),
    getSettings(),
  ]);

  // Only sellable items show on the order screen.
  const available = products.filter((p: any) => p.isAvailable !== false);

  return (
    <OrderBuilder
      orderType={(type as "dine_in" | "takeaway" | "delivery") || "dine_in"}
      products={available}
      waiters={waiters}
      categories={categories}
      speedDial={(settings as any).speedDial || {}}
      autoFillDeliveryAddress={(settings as any).autoFillDeliveryAddress ?? true}
      storeName={(settings as any).storeName || "Sevesto Cafe"}
      storeAddress={(settings as any).storeAddress || ""}
      storePhone={(settings as any).storePhone || ""}
      posDisplayLogo={(settings as any).posDisplayLogo || ""}
    />
  );
}
