"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useAutoAnimate } from "@formkit/auto-animate/react";
import { toast } from "sonner";
import { Plus, Minus } from "lucide-react";
import AppLayout from "../Layout/AppLayout";

type Variant = { name: string; price: number };

type Product = {
  _id: string;
  name: string;
  price: number;
  category: { _id: string; name: string; sortOrder: number } | string;
  hasVariants?: boolean;
  variants?: Variant[];
};

type Category = { _id: string; name: string; sortOrder: number };

type Waiter = { _id: string; name: string };

type CartLine = {
  key: string;                 // productId or productId::variantIndex — variants stay distinct lines
  productId: string;
  variantIndex?: number;       // only for grouped-variant products
  name: string;
  price: number;
  qty: number;
  lineDiscountPercent: number;
};

type OrderType = "dine_in" | "takeaway" | "delivery";

type Customer = { _id: string; name?: string; phone: string; loyaltyPoints?: number; lastAddress?: string };

type SpeedDialMap = Record<string, string>;

const TYPE_LABEL: Record<OrderType, string> = {
  dine_in: "Dine In",
  takeaway: "Take Away",
  delivery: "Delivery",
};

const GUEST_PHONE = "0000000000";

type VariantOption = { label: string; price: number; product?: Product; index?: number };

export default function OrderBuilder({
  orderType,
  products,
  waiters,
  categories,
  speedDial = {},
  autoFillDeliveryAddress = true,
  storeName = "Sevesto Cafe",
  storeAddress = "",
  storePhone = "",
  posDisplayLogo = "",
}: {
  orderType: OrderType;
  products: Product[];
  waiters: Waiter[];
  categories: Category[];
  speedDial?: SpeedDialMap;
  autoFillDeliveryAddress?: boolean;
  storeName?: string;
  storeAddress?: string;
  storePhone?: string;
  posDisplayLogo?: string;
}) {
  const router = useRouter();

  const [intakeDone, setIntakeDone] = useState(false);
  const [dineInCustomerSelected, setDineInCustomerSelected] = useState(false);
  const [guests, setGuests] = useState<number | "">("");
  const [table, setTable] = useState("");
  const [guestsTouched, setGuestsTouched] = useState(false);

  const [customerQuery, setCustomerQuery] = useState("");
  const [customerResults, setCustomerResults] = useState<Customer[]>([]);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [deliveryAddress, setDeliveryAddress] = useState("");

  const [showCustomerSearch, setShowCustomerSearch] = useState(false);
  const [dineInCustomerQuery, setDineInCustomerQuery] = useState("");
  const [dineInCustomerResults, setDineInCustomerResults] = useState<Customer[]>([]);

  const sortedCategories = useMemo(
    () => [...categories].sort((a, b) => a.sortOrder - b.sortOrder),
    [categories]
  );
  const categoryNames = useMemo(() => sortedCategories.map((c) => c.name), [sortedCategories]);
  const [activeCategory, setActiveCategory] = useState(categoryNames[0] ?? "");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [discountPercent, setDiscountPercent] = useState(0);
  const [deliveryCharges, setDeliveryCharges] = useState(0);
  const [note, setNote] = useState("");
  const [waiterId, setWaiterId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [variantModal, setVariantModal] = useState<ProductGroup | null>(null);
  const [qtyEditIndex, setQtyEditIndex] = useState<number | null>(null);
  const [qtyEditValue, setQtyEditValue] = useState("");

  const [cartParent] = useAutoAnimate<HTMLDivElement>();

  // --- Guests numpad: physical keyboard support ---
  useEffect(() => {
    if (intakeDone || orderType !== "dine_in" || !dineInCustomerSelected) return;

    function handleKey(e: KeyboardEvent) {
      const active = document.activeElement;
      if (active && active.tagName === "INPUT") return;

      if (e.key >= "0" && e.key <= "9") {
        const n = parseInt(e.key, 10);
        setGuests((prev) => {
          const current = prev === "" ? 0 : prev;
          const next = current * 10 + n;
          return next <= 50 ? next : current;
        });
      } else if (e.key === "Backspace") {
        setGuests((prev) => (typeof prev === "number" ? Math.floor(prev / 10) : ""));
      } else if (e.key === "Enter") {
        setGuests((prev) => {
          if (prev !== "") { setIntakeDone(true); return prev; }
          setGuestsTouched(true);
          return prev;
        });
      }
    }

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [intakeDone, orderType, dineInCustomerSelected]);

  // --- Speed dial keyboard handler ---
  useEffect(() => {
    if (!intakeDone) return;

    function handleKeyDown(e: KeyboardEvent) {
      const active = document.activeElement;
      if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA" || active.tagName === "SELECT")) {
        return;
      }
      if (e.key >= "0" && e.key <= "9") {
        const productId = speedDial[e.key];
        if (productId) {
          const product = products.find((p) => p._id === productId && !(p.hasVariants && p.variants && p.variants.length));
          if (product) {
            e.preventDefault();
            addToCart(product);
          }
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [intakeDone, speedDial, products]);

  async function searchCustomers(q: string) {
    setCustomerQuery(q);
    if (q.trim().length < 2) { setCustomerResults([]); return; }
    const res = await fetch(`/api/customers?query=${encodeURIComponent(q)}`);
    if (res.ok) setCustomerResults(await res.json());
  }

  async function searchDineInCustomers(q: string) {
    setDineInCustomerQuery(q);
    if (q.trim().length < 2) { setDineInCustomerResults([]); return; }
    const res = await fetch(`/api/customers?query=${encodeURIComponent(q)}`);
    if (res.ok) setDineInCustomerResults(await res.json());
  }

  async function useGuestCustomer() {
    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone: GUEST_PHONE }),
    });
    if (res.ok) setCustomer(await res.json());
  }

  async function createCustomer(q: string) {
    const input = q.trim();
    if (input.length < 3) {
      toast.error("Invalid input", { description: "Enter at least 3 characters" });
      return;
    }

    const isPhone = /^\d+$/.test(input);
    if (isPhone && (input.length < 10 || input.length > 11)) {
      toast.error("Invalid phone", { description: "Enter 10-11 digits" });
      return;
    }
    const payload = isPhone ? { phone: input } : { name: input, phone: "03000000000" };
    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      toast.error("Failed to create customer");
      return;
    }
    const newCustomer = await res.json();

    setCustomer(newCustomer);
    if (autoFillDeliveryAddress && orderType === "delivery" && (newCustomer as any).lastAddress) {
      setDeliveryAddress((newCustomer as any).lastAddress);
    }

    setCustomerQuery(newCustomer.phone === "03000000000" ? newCustomer.name || "" : newCustomer.phone);
    setCustomerResults([]);
    setDineInCustomerQuery(newCustomer.phone === "03000000000" ? (newCustomer.name || "") : newCustomer.phone);
    setDineInCustomerResults([]);
    setDineInCustomerSelected(true);
    setShowCustomerSearch(false);
  }

  // --- Cart / variants ---
  function addToCart(product: Product, variant?: { index: number; name: string; price: number }) {
    const key = variant ? `${product._id}::${variant.index}` : product._id;
    setCart((prev) => {
      const idx = prev.findIndex((l) => l.key === key);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], qty: next[idx].qty + 1 };
        return next;
      }
      return [
        ...prev,
        {
          key,
          productId: product._id,
          variantIndex: variant?.index,
          name: variant ? `${product.name} (${variant.name})` : product.name,
          price: variant ? variant.price : product.price,
          qty: 1,
          lineDiscountPercent: 0,
        },
      ];
    });
  }

  function updateQty(index: number, delta: number) {
    setCart((prev) => {
      const next = [...prev];
      const line = next[index];
      const qty = line.qty + delta;
      if (qty <= 0) {
        next.splice(index, 1);
        setSelectedIndex(null);
      } else {
        next[index] = { ...line, qty };
      }
      return next;
    });
  }

  function removeLine(index: number) {
    setCart((prev) => prev.filter((_, i) => i !== index));
    setSelectedIndex(null);
  }

  const subtotal = cart.reduce((sum, l) => sum + l.price * l.qty * (1 - l.lineDiscountPercent / 100), 0);
  const total = subtotal * (1 - discountPercent / 100) + (orderType === "delivery" ? deliveryCharges : 0);

  async function confirmOrder() {
    if (cart.length === 0 || submitting) return;
    setSubmitting(true);

    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type: orderType,
        items: cart.map((l) => ({
          productId: l.productId,
          qty: l.qty,
          lineDiscountPercent: l.lineDiscountPercent,
          ...(l.variantIndex !== undefined ? { variantIndex: l.variantIndex } : {}),
        })),
        table: orderType === "dine_in" ? table : undefined,
        guests: orderType === "dine_in" ? Number(guests) : undefined,
        customerId: customer?._id,
        deliveryAddress: orderType === "delivery" ? deliveryAddress : undefined,
        deliveryCharges: orderType === "delivery" ? deliveryCharges : undefined,
        waiterId: waiterId || undefined,
        discountPercent,
        note,
      }),
    });

    setSubmitting(false);
    if (res.ok) {
      const data = await res.json();
      toast.success("Order placed", { className: "bg-gray-900 text-white text-sm" });
      if (data.printResult?.success) {
        toast.success("Kitchen ticket printed", { className: "bg-brand-600 text-white text-sm", duration: 4000 });
      } else {
        toast.error("Kitchen ticket failed to print", {
          description: data.printResult?.error || "Check printer connection",
          className: "bg-red-600 text-white text-sm",
        });
      }
      router.push(`/pos?tab=${orderType}`);
    } else {
      const d = await res.json().catch(() => ({}));
      toast.error("Failed to place order", { description: typeof d.error === "string" ? d.error : "" });
    }
  }

  // ---------- Intake step ----------
  const renderIntake = () => {
    if (!intakeDone) {
      if (orderType === "dine_in" && !dineInCustomerSelected) {
        return (
          <div className="flex flex-col items-center justify-center h-full gap-6 px-6 bg-stone-50">
            <div className="text-center">
              <h1 className="text-xl font-semibold text-stone-900">
                Customer <span className="text-stone-400 font-normal">(required)</span>
              </h1>
              <p className="text-sm text-stone-500 mt-1">Search by phone/name, create one, or use the shared Walk-in Guest record.</p>
            </div>
            <div className="w-full max-w-md">
              <input
                autoFocus
                value={customerQuery}
                onChange={(e) => searchCustomers(e.target.value)}
                onKeyDown={async (e) => {
                  if (e.key !== "Enter") return;
                  if (customerResults.length > 0) {
                    const c = customerResults[0];
                    setCustomer(c);
                    setCustomerQuery(c.phone);
                    setCustomerResults([]);
                    setDineInCustomerSelected(true);
                  } else if (customerQuery.trim().length >= 3) {
                    await createCustomer(customerQuery);
                  } else {
                    toast.info("No customer found — use Walk-in Guest or create one");
                  }
                }}
                placeholder="Search name or phone…"
                className="input py-3 text-base"
              />
              <AnimatePresence>
                {customerResults.length > 0 && (
                  <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} className="mt-2 bg-white border border-stone-200 rounded-lg shadow-sm overflow-hidden">
                    {customerResults.map((c) => (
                      <button
                        key={c._id}
                        onClick={() => {
                          setCustomer(c);
                          setCustomerQuery(c.phone);
                          setCustomerResults([]);
                          setDineInCustomerSelected(true);
                        }}
                        className="w-full text-left px-4 py-3 hover:bg-stone-50 flex justify-between items-center border-b border-stone-100 last:border-0"
                      >
                        <span className="font-medium text-stone-900">{c.name || "Guest"}</span>
                        <span className="text-sm text-stone-500 tabular">{c.phone} · {c.loyaltyPoints ?? 0} pts</span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
              {customerQuery.trim().length >= 3 && customerResults.length === 0 && (
                <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} onClick={async () => await createCustomer(customerQuery)} className="mt-2 w-full py-3 rounded-lg border-2 border-dashed border-stone-300 text-brand-700 font-medium hover:bg-brand-50 transition-colors">
                  + Create "{customerQuery}"
                </motion.button>
              )}
            </div>

            <button
              onClick={async () => {
                await useGuestCustomer();
                setCustomerQuery("");
                setCustomerResults([]);
                setDineInCustomerSelected(true);
              }}
              className="px-6 py-3 rounded-lg bg-brand-600 text-white font-medium hover:bg-brand-700 transition-colors"
            >
              Walk-in Guest
            </button>
          </div>
        );
      }

      if (orderType === "dine_in") {
        return (
          <div className="flex flex-col items-center justify-center h-full gap-6 px-6 bg-stone-50">
            <div className="flex items-center gap-3">
              <button onClick={() => setDineInCustomerSelected(false)} className="text-sm text-brand-700 hover:text-brand-800 font-medium">
                ← Change
              </button>
              <span className="text-sm text-stone-500">
                {customer?.name || customer?.phone ? `${customer?.name || "Guest"} · ${customer?.phone}` : "No customer"}
              </span>
            </div>

            <div className="text-center">
              <div className="text-sm text-stone-500 mb-1">Guests</div>
              <div className="text-5xl font-bold text-stone-900 w-24 text-center tabular">{guests === "" ? "0" : guests}</div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
                <button
                  key={n}
                  onClick={() => setGuests((prev) => {
                    const current = prev === "" ? 0 : prev;
                    const next = current * 10 + n;
                    return next <= 50 ? next : current;
                  })}
                  className="w-16 h-14 rounded-lg bg-white border border-stone-200 text-xl font-medium text-stone-900 hover:bg-stone-50 active:bg-stone-100 transition-colors"
                >
                  {n}
                </button>
              ))}
              <button onClick={() => setGuests("")} className="w-16 h-14 rounded-lg bg-stone-100 border border-stone-200 text-sm font-medium text-stone-600 hover:bg-stone-200 transition-colors">Clear</button>
              <button onClick={() => setGuests((prev) => {
                const current = prev === "" ? 0 : prev;
                const next = current * 10;
                return next <= 50 ? next : current;
              })} className="w-16 h-14 rounded-lg bg-white border border-stone-200 text-xl font-medium text-stone-900 hover:bg-stone-50 active:bg-stone-100 transition-colors">0</button>
              <button onClick={() => setGuests((prev: number | "") => typeof prev === "number" ? Math.floor(prev / 10) : "")} className="w-16 h-14 rounded-lg bg-stone-100 border border-stone-200 text-sm font-medium text-stone-600 hover:bg-stone-200 transition-colors">⌫</button>
            </div>

            <input
              autoFocus
              value={table}
              onChange={(e) => setTable(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && typeof guests === "number" && guests > 0) setIntakeDone(true); }}
              placeholder="Table number (optional)"
            />

            {waiters.length > 0 && (
              <select
                value={waiterId}
                onChange={(e) => setWaiterId(e.target.value)}
                className="input w-48"
              >
                <option value="">Set Waiter (optional)</option>
                {waiters.map((w) => <option key={w._id} value={w._id}>{w.name}</option>)}
              </select>
            )}

            <button
              onClick={() => {
                if (guests === "" || guests <= 0) { setGuestsTouched(true); return; }
                setIntakeDone(true);
              }}
              className="px-10 py-3 rounded-lg bg-brand-600 text-white font-medium hover:bg-brand-700 transition-colors"
            >
              Continue
            </button>
            {guestsTouched && (guests === "" || guests <= 0) && (
              <p className="text-sm font-medium text-amber-700">Guests must be at least 1</p>
            )}
          </div>
        );
      }

      return (
        <div className="flex flex-col items-center justify-center h-full gap-6 px-6 bg-stone-50">
          <div className="text-center">
            <h1 className="text-xl font-semibold text-stone-900">
              Customer {orderType === "delivery" && <span className="text-stone-400 font-normal ml-1">(for delivery)</span>}
            </h1>
          </div>
          <div className="w-full max-w-md">
            <input
              autoFocus
              value={customerQuery}
              onChange={(e) => searchCustomers(e.target.value)}
              onKeyDown={async (e) => {
                if (e.key !== "Enter") return;
                if (customerResults.length > 0) {
                  const c = customerResults[0];
                  setCustomer(c);
                  setCustomerQuery(c.phone);
                  setCustomerResults([]);
                  if (autoFillDeliveryAddress && orderType === "delivery" && (c as any).lastAddress) {
                    setDeliveryAddress((c as any).lastAddress);
                  }
                } else if (customerQuery.trim().length >= 3) {
                  await createCustomer(customerQuery);
                }
              }}
              placeholder="Search name or phone…"
              className="input py-3 text-base"
            />
            <AnimatePresence>
              {customerResults.length > 0 && (
                <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} className="mt-2 bg-white border border-stone-200 rounded-lg shadow-sm overflow-hidden">
                  {customerResults.map((c) => (
                    <button
                      key={c._id}
                      onClick={() => {
                        setCustomer(c);
                        setCustomerQuery(c.phone);
                        setCustomerResults([]);
                        if (autoFillDeliveryAddress && orderType === "delivery" && (c as any).lastAddress) {
                          setDeliveryAddress((c as any).lastAddress);
                        }
                      }}
                      className="w-full text-left px-4 py-3 hover:bg-stone-50 flex justify-between items-center border-b border-stone-100 last:border-0"
                    >
                      <span className="font-medium text-stone-900">{c.name || "Guest"}</span>
                      <span className="text-sm text-stone-500 tabular">{c.phone} · {c.loyaltyPoints ?? 0} pts</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
            {customerQuery.trim().length >= 3 && customerResults.length === 0 && (
              <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} onClick={async () => await createCustomer(customerQuery)} className="mt-2 w-full py-3 rounded-lg border-2 border-dashed border-stone-300 text-brand-700 font-medium hover:bg-brand-50 transition-colors">
                + Create "{customerQuery}"
              </motion.button>
            )}
          </div>

          {orderType === "delivery" && customer && (
            <input
              value={deliveryAddress}
              onChange={(e) => setDeliveryAddress(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && customer) setIntakeDone(true); }}
              placeholder="Delivery address"
              className="input py-3 w-full max-w-md"
            />
          )}

          <div className="flex gap-3">
            {orderType === "takeaway" && (
              <button
                onClick={async () => {
                  await useGuestCustomer();
                  setIntakeDone(true);
                }}
                className="px-6 py-3 rounded-lg border-2 border-stone-200 text-stone-700 font-medium hover:bg-stone-50 transition-colors"
              >
                Walk-in Guest
              </button>
            )}
            <button
              disabled={!customer && customerQuery.trim().length < 3}
              onClick={async () => {
                if (!customer && customerQuery.trim().length >= 3) {
                  await createCustomer(customerQuery);
                  if (orderType !== "delivery") setIntakeDone(true);
                } else {
                  setIntakeDone(true);
                }
              }}
              className="px-10 py-3 rounded-lg bg-brand-600 text-white font-medium disabled:opacity-40 hover:bg-brand-700 transition-colors"
            >
              {orderType === "delivery" ? (!customer ? "Continue" : "Set Delivery") : "Set Customer"}
            </button>
          </div>
        </div>
      );
    }
  };

  // ---------- Product grouping ----------
  type ProductGroup = { baseName: string; base?: Product; options: VariantOption[]; isSingle: boolean };

  function getProductGroups(productList: Product[]): ProductGroup[] {
    const map = new Map<string, { base?: Product; options: VariantOption[] }>();
    for (const p of productList) {
      if (p.hasVariants && p.variants && p.variants.length > 0) {
        const entry = map.get(p.name) ?? { base: p, options: [] };
        p.variants.forEach((v, i) => entry.options.push({ label: v.name, price: v.price, index: i }));
        map.set(p.name, entry);
      } else {
        const baseName = p.name.includes(" (") ? p.name.split(" (")[0].trim() : p.name;
        const entry = map.get(baseName) ?? { options: [] };
        if (!entry.base) entry.base = p;
        entry.options.push({ label: p.name, price: p.price, product: p });
        map.set(baseName, entry);
      }
    }
    return Array.from(map.entries()).map(([baseName, entry]) => ({
      baseName,
      base: entry.base,
      options: entry.options,
      isSingle: entry.options.length === 1,
    }));
  }

  function addOption(group: ProductGroup, opt: VariantOption) {
    if (opt.product) {
      addToCart(opt.product);
    } else if (group.base) {
      addToCart(group.base, { index: opt.index!, name: opt.label, price: opt.price });
    }
  }

  const searchBar = (
    <div className="relative flex items-center gap-3">
      <svg className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
      <input
        type="text"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        placeholder="Search items..."
        className="w-72 pl-9 pr-4 py-2 bg-stone-50 border border-stone-200 rounded-lg text-sm focus:outline-none focus:border-brand-600 focus:bg-white transition-colors"
      />
    </div>
  );

  return (
    <AppLayout headerMiddleContent={intakeDone ? searchBar : null}>
      <main className="h-full bg-white flex flex-col">
        {!intakeDone ? renderIntake() : (
          <div className="flex flex-row-reverse h-full bg-white">
            {/* Cart panel */}
            <div className="w-[360px] bg-white border-l border-stone-200 flex flex-col shrink-0 z-10">
              <div className="px-6 py-5 border-b border-stone-100">
                {posDisplayLogo ? (
                  <img src={posDisplayLogo} alt={storeName} className="h-8 mb-2 object-contain" />
                ) : (
                  <div className="text-[22px] font-bold text-stone-900 tracking-tight font-brand">{storeName || "Sevesto Cafe"}</div>
                )}
                <div className="text-sm text-stone-500 mt-1 flex items-center gap-2">
                  <span>{TYPE_LABEL[orderType]}</span>
                  <span>·</span>
                  {orderType === "dine_in" ? (
                    <span>Table {table || "—"} · {guests || 0} guests</span>
                  ) : (
                    <span className="truncate">{customer?.name || customer?.phone || "No customer"}</span>
                  )}
                </div>
              </div>

              <div className="px-6 py-4 flex items-center justify-between border-b border-stone-50">
                <h2 className="text-[17px] font-bold text-stone-900">Order</h2>
                <button onClick={() => setCart([])} className="text-sm font-semibold text-brand-700 hover:text-brand-800 transition-colors">Clear</button>
              </div>

              {Object.keys(speedDial).length > 0 && (
                <div className="px-3 py-2 border-b border-stone-100 bg-stone-50">
                  <div className="text-xs font-medium text-stone-400 uppercase tracking-wider mb-1.5">Speed Dial</div>
                  <div className="grid grid-cols-5 gap-1">
                    {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => {
                      const productId = speedDial[String(num)];
                      const product = productId ? products.find((p) => p._id === productId) : null;
                      return (
                        <div
                          key={num}
                          id={`speed-dial-${num}`}
                          className={`aspect-square rounded border text-xs flex flex-col items-center justify-center transition-colors ${
                            product && !(product.hasVariants && product.variants && product.variants.length)
                              ? "border-brand-200 bg-brand-50 text-brand-700 cursor-pointer hover:bg-brand-100 active:bg-brand-200"
                              : "border-stone-200 bg-stone-100 text-stone-300"
                          }`}
                          onClick={() => { if (product && !(product.hasVariants && product.variants && product.variants.length)) addToCart(product); }}
                          title={product ? `${product.name} — Rs.${product.price}` : "Unassigned"}
                        >
                          <span className="font-bold">{num}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div ref={cartParent} className="flex-1 overflow-y-auto">
                {cart.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-full gap-4 text-stone-400">
                    <div className="text-center">
                      <div className="text-sm font-medium text-stone-500">No items added yet</div>
                      <div className="text-sm text-stone-400 mt-1">Select items from the menu</div>
                    </div>
                  </div>
                )}
                <AnimatePresence initial={false} mode="popLayout">
                  {cart.map((line, i) => (
                    <motion.div
                      key={line.key}
                      layout
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95, height: 0 }}
                      transition={{ duration: 0.12 }}
                      onClick={() => setSelectedIndex(i)}
                      className={`flex items-center gap-3 px-3 py-2.5 border-b border-stone-50 cursor-pointer transition-colors ${
                        selectedIndex === i ? "bg-brand-50 border-l-2 border-l-brand-600" : "border-l-2 border-l-transparent"
                      }`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-stone-900 text-sm truncate">{line.name}</div>
                        <div className="text-xs text-stone-400 mt-0.5 tabular">
                          Rs. {line.price} × {line.qty}
                          {line.lineDiscountPercent > 0 && <span className="text-green-700 ml-1">−{line.lineDiscountPercent}%</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <button onClick={(e) => { e.stopPropagation(); updateQty(i, -1); }} className="w-7 h-7 rounded flex items-center justify-center bg-stone-100 hover:bg-stone-200 active:bg-stone-300 transition-colors">
                          <Minus className="w-3 h-3 text-stone-600" />
                        </button>
                        {qtyEditIndex === i ? (
                          <input
                            autoFocus
                            type="text"
                            value={qtyEditValue}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => setQtyEditValue(e.target.value.replace(/\D/g, ""))}
                            onBlur={() => {
                              const n = parseInt(qtyEditValue, 10);
                              if (n > 0) {
                                setCart((prev) => { const next = [...prev]; next[i] = { ...next[i], qty: n }; return next; });
                              } else if (n === 0) {
                                removeLine(i);
                              }
                              setQtyEditIndex(null);
                            }}
                            onKeyDown={(e) => { if (e.key === "Enter" || e.key === "Escape") (e.target as HTMLInputElement).blur(); }}
                            className="w-10 text-center text-sm font-semibold text-stone-900 border border-brand-400 rounded outline-none bg-brand-50 px-1 py-0.5"
                          />
                        ) : (
                          <span
                            onClick={(e) => { e.stopPropagation(); setQtyEditIndex(i); setQtyEditValue(String(line.qty)); }}
                            title="Click to edit quantity"
                            className="w-7 text-center text-sm font-semibold text-stone-900 cursor-text hover:bg-stone-100 rounded px-1 tabular"
                          >
                            {line.qty}
                          </span>
                        )}
                        <button onClick={(e) => { e.stopPropagation(); updateQty(i, 1); }} className="w-7 h-7 rounded flex items-center justify-center bg-brand-100 hover:bg-brand-200 active:bg-brand-300 transition-colors">
                          <Plus className="w-3 h-3 text-brand-700" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {selectedIndex !== null && cart[selectedIndex] && (
                <div className="border-t border-stone-200 px-3 py-2 bg-stone-50">
                  <button onClick={() => removeLine(selectedIndex)} className="w-full py-1.5 rounded text-xs font-medium text-red-600 hover:bg-red-50 transition-colors">Remove item</button>
                </div>
              )}

              <div className="border-t border-stone-200 px-4 py-3 space-y-2 bg-white">
                <div className="flex items-center gap-2">
                  <label className="text-xs text-stone-500 shrink-0">Discount %</label>
                  <input type="number" min={0} max={100} value={discountPercent} onChange={(e) => setDiscountPercent(Number(e.target.value))} className="input w-16 text-right" />
                </div>
                {orderType === "delivery" && (
                  <div className="flex items-center gap-2">
                    <label className="text-xs text-stone-500 shrink-0">Delivery</label>
                    <input type="number" min={0} value={deliveryCharges} onChange={(e) => setDeliveryCharges(Number(e.target.value))} className="input w-20 text-right" />
                  </div>
                )}
                {waiters.length > 0 && orderType === "dine_in" && (
                  <select value={waiterId} onChange={(e) => setWaiterId(e.target.value)} className="input">
                    <option value="">Set Waiter</option>
                    {waiters.map((w) => <option key={w._id} value={w._id}>{w.name}</option>)}
                  </select>
                )}
                {orderType === "dine_in" && (
                  <div>
                    {!showCustomerSearch ? (
                      customer ? (
                        <div className="text-xs text-stone-500 truncate">
                          {customer.name || "Guest"} · {customer.phone === GUEST_PHONE ? "Walk-in" : `${customer.phone} · ${customer.loyaltyPoints ?? 0} pts`}
                          <button onClick={() => setShowCustomerSearch(true)} className="ml-1 text-brand-700 hover:text-brand-800 font-medium">change</button>
                        </div>
                      ) : (
                        <button onClick={() => setShowCustomerSearch(true)} className="text-xs text-brand-700 hover:text-brand-800 font-medium">+ Link customer</button>
                      )
                    ) : (
                      <div className="space-y-1.5">
                        <input autoFocus value={dineInCustomerQuery} onChange={(e) => searchDineInCustomers(e.target.value)} placeholder="Search…" className="input" />
                        <div className="max-h-32 overflow-y-auto space-y-0.5">
                          {dineInCustomerResults.map((c) => (
                            <button
                              key={c._id}
                              type="button"
                              onClick={() => { setCustomer(c); setDineInCustomerQuery(c.phone); setDineInCustomerResults([]); setShowCustomerSearch(false); }}
                              className="w-full text-left px-2 py-1.5 rounded text-xs hover:bg-stone-100"
                            >
                              <div className="font-medium text-stone-900">{c.name || "Guest"}</div>
                              <div className="text-stone-500 tabular">{c.phone} · {c.loyaltyPoints ?? 0} pts</div>
                            </button>
                          ))}
                          {dineInCustomerQuery.length >= 10 && dineInCustomerResults.length === 0 && (
                            <button
                              type="button"
                              onClick={async () => {
                                const phone = dineInCustomerQuery.trim();
                                if (phone.length < 10 || phone.length > 11 || !/^\d+$/.test(phone)) { toast.error("Invalid phone"); return; }
                                const res = await fetch("/api/customers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ phone }) });
                                if (res.ok) { const nc = await res.json(); setCustomer(nc); setDineInCustomerQuery(nc.phone); setDineInCustomerResults([]); setShowCustomerSearch(false); }
                              }}
                              className="w-full text-left text-xs text-brand-700 hover:text-brand-800 py-1"
                            >
                              + Create "{dineInCustomerQuery}"
                            </button>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <button onClick={async () => { await useGuestCustomer(); setDineInCustomerQuery(""); setDineInCustomerResults([]); setShowCustomerSearch(false); }} className="flex-1 text-xs text-brand-700 hover:text-brand-800 py-1">Guest</button>
                          <button onClick={() => { setShowCustomerSearch(false); setDineInCustomerQuery(""); setDineInCustomerResults([]); }} className="flex-1 text-xs text-stone-500 hover:text-stone-700 py-1">Cancel</button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
                <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Order note…" className="input text-xs resize-none" rows={2} />
              </div>

              <div className="border-t border-stone-200 px-4 py-3 bg-stone-50 space-y-1">
                <div className="flex justify-between text-xs text-stone-500">
                  <span>Subtotal</span>
                  <span className="tabular">Rs. {subtotal.toFixed(2)}</span>
                </div>
                {discountPercent > 0 && (
                  <div className="flex justify-between text-xs text-green-700">
                    <span>Discount ({discountPercent}%)</span>
                    <span className="tabular">−Rs. {(subtotal * discountPercent / 100).toFixed(2)}</span>
                  </div>
                )}
                {orderType === "delivery" && deliveryCharges > 0 && (
                  <div className="flex justify-between text-xs text-stone-500">
                    <span>Delivery</span>
                    <span className="tabular">Rs. {deliveryCharges.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-bold text-stone-900 pt-1 border-t border-stone-200">
                  <span>Total</span>
                  <span className="tabular">Rs. {total.toFixed(2)}</span>
                </div>
              </div>

              <div className="p-4 border-t border-stone-100 bg-white">
                <button
                  disabled={cart.length === 0 || submitting}
                  onClick={confirmOrder}
                  className="w-full py-4 rounded-xl bg-brand-600 text-white font-semibold disabled:opacity-40 hover:bg-brand-700 active:bg-brand-800 transition-colors text-base flex items-center justify-between px-4"
                >
                  <span>{submitting ? "Placing…" : "Confirm Order"}</span>
                  <span className="tabular">Rs. {total.toFixed(2)}</span>
                </button>
              </div>
            </div>

            {/* Category tabs + product grid */}
            <div className="flex-1 flex flex-col min-w-0 bg-stone-50/50">
              {!searchQuery && (
                <div className="flex flex-wrap gap-2.5 px-6 py-4 border-b border-stone-100 bg-white">
                  {categoryNames.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-5 py-2.5 rounded-lg text-sm font-semibold whitespace-nowrap transition-all border ${
                        activeCategory === cat
                          ? "bg-brand-600 text-white border-brand-600"
                          : "bg-white text-stone-600 border-stone-200 hover:border-stone-300 hover:bg-stone-50"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              )}

              <div className="flex-1 overflow-auto p-6 bg-white">
                {(() => {
                  const filtered = searchQuery
                    ? products.filter((p) => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
                    : products.filter((p) => {
                        const catName = typeof p.category === "object" ? p.category.name : p.category;
                        return catName === activeCategory;
                      });

                  const groups = getProductGroups(filtered);

                  return (
                    <>
                      <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold text-stone-900 font-brand">
                          {searchQuery ? `Results for "${searchQuery}"` : activeCategory}
                        </h2>
                        <span className="text-sm text-stone-400 font-medium">{groups.length} items</span>
                      </div>

                      {groups.length === 0 && (
                        <div className="flex flex-col items-center justify-center h-48 gap-3 text-stone-400">
                          <p className="text-sm">No items found</p>
                        </div>
                      )}

                      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 content-start">
                        {groups.map((group) => (
                          <motion.button
                            key={group.baseName}
                            whileTap={{ scale: 0.96 }}
                            onClick={() => {
                              if (group.isSingle) addOption(group, group.options[0]);
                              else setVariantModal(group);
                            }}
                            className="bg-white border border-stone-200 rounded-2xl p-5 text-left hover:border-brand-400 hover:shadow-sm transition-all flex flex-col justify-between min-h-[140px]"
                          >
                            <div>
                              <div className="font-bold text-stone-900 text-[15px] leading-tight group-hover:text-brand-700 transition-colors">{group.baseName}</div>
                              {!group.isSingle && (
                                <div className="flex flex-wrap gap-1 mt-2">
                                  {group.options.slice(0, 5).map((v, i) => (
                                    <span key={i} className="text-[11px] px-2 py-0.5 bg-brand-50 text-brand-700 rounded-sm font-medium">{v.label}</span>
                                  ))}
                                  {group.options.length > 5 && <span className="text-[11px] px-2 py-0.5 text-stone-400 font-medium">+{group.options.length - 5}</span>}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center justify-between w-full mt-4">
                              <div className="text-[15px] font-bold text-green-700 tabular">
                                {group.isSingle
                                  ? `Rs. ${group.options[0].price.toFixed(2)}`
                                  : `From Rs. ${Math.min(...group.options.map((v) => v.price)).toFixed(2)}`}
                              </div>
                              <div className="w-8 h-8 rounded-lg border border-stone-200 flex items-center justify-center bg-white text-stone-400">
                                <Plus className="w-4 h-4" />
                              </div>
                            </div>
                          </motion.button>
                        ))}
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Variant/Size picker modal */}
      <AnimatePresence>
        {variantModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
            onClick={() => setVariantModal(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden"
            >
              <div className="px-6 py-5 border-b border-stone-100 flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-stone-900 font-brand">{variantModal.baseName}</h3>
                  <p className="text-sm text-stone-400 mt-0.5">Select a size to add to cart</p>
                </div>
                <button onClick={() => setVariantModal(null)} className="w-8 h-8 rounded-lg flex items-center justify-center text-stone-400 hover:bg-stone-100 hover:text-stone-600 transition-colors">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>

              <div className="p-4 space-y-2 max-h-[60vh] overflow-y-auto">
                {variantModal.options.map((opt, i) => (
                  <motion.button
                    key={i}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => { addOption(variantModal, opt); setVariantModal(null); }}
                    className="w-full flex items-center justify-between px-4 py-3.5 rounded-xl border border-stone-200 hover:border-brand-400 hover:bg-brand-50 transition-all"
                  >
                    <span className="font-semibold text-stone-800">{opt.label}</span>
                    <span className="text-[15px] font-bold text-green-700 tabular">Rs. {opt.price.toFixed(2)}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AppLayout>
  );
}
