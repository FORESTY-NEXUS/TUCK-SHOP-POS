"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  LayoutGrid,
  UtensilsCrossed,
  Coffee,
  Bike,
  Plus,
  LogOut,
  Maximize2,
  Minimize2,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import ShiftBar from "./ShiftBar";
import DeliveryReadyPopup from "./DeliveryReadyPopup";
import { useFullscreen } from "@/hooks/useFullscreen";

type OrderType = "dine_in" | "takeaway" | "delivery";

type CockpitOrder = {
  _id: string;
  orderNumber: string;
  type: OrderType;
  table?: string;
  status: string;
  total: number;
  subtotal?: number;
  discountAmount?: number;
  discountPercent?: number;
  deliveryCharges?: number;
  isPaid: boolean;
  paymentMethod?: string;
  paidAmount?: number;
  createdAt: string;
  customer?: { name?: string; phone?: string; loyaltyPoints?: number };
  waiter?: { name?: string };
  rider?: { name?: string };
  items?: Array<{
    name: string;
    price: number;
    qty: number;
    lineDiscountPercent?: number;
    qtyRefunded?: number;
  }>;
  deliveryAddress?: string;
  refundedAmount?: number;
};

type RiderOption = { _id: string; name: string };

const TABS: { key: OrderType; label: string; icon: React.ElementType }[] = [
  { key: "dine_in", label: "Dine In", icon: UtensilsCrossed },
  { key: "takeaway", label: "Take Away", icon: Coffee },
  { key: "delivery", label: "Delivery", icon: Bike },
];

const QUICK_ORDER_TYPES: { type: OrderType; label: string; icon: React.ElementType }[] = [
  { type: "dine_in", label: "Dine In", icon: UtensilsCrossed },
  { type: "takeaway", label: "Takeaway", icon: Coffee },
  { type: "delivery", label: "Delivery", icon: Bike },
];

const STATUS_STYLES: Record<string, string> = {
  preparing: "bg-amber-100 text-amber-800",
  ready: "bg-brand-100 text-brand-800",
  dispatched: "bg-stone-200 text-stone-700",
  completed: "bg-green-100 text-green-800",
  cancelled: "bg-stone-200 text-stone-600",
  refunded: "bg-red-100 text-red-700",
  partially_refunded: "bg-red-50 text-red-600",
};

function actionFor(order: CockpitOrder): { label: string; className: string } {
  if (order.type === "dine_in") {
    if (!order.isPaid) {
      if (order.status === "preparing") return { label: "Ready", className: "bg-orange-600 hover:bg-orange-700" };
      if (order.status === "ready") return { label: "Completed", className: "bg-brand-600 hover:bg-brand-700" };
      if (order.status === "completed") return { label: "Cash Out", className: "bg-brand-600 hover:bg-brand-700" };
    }
    if (order.isPaid && (order.status === "completed" || order.status === "partially_refunded")) {
      return { label: "Refund", className: "bg-red-600 hover:bg-red-700" };
    }
    return { label: "Reprint Kitchen", className: "bg-stone-500 hover:bg-stone-600" };
  }

  if (order.type === "takeaway") {
    if (!order.isPaid) {
      if (order.status === "preparing") return { label: "Ready", className: "bg-orange-600 hover:bg-orange-700" };
      if (order.status === "ready") return { label: "Completed", className: "bg-brand-600 hover:bg-brand-700" };
      if (order.status === "completed") return { label: "Take Payment", className: "bg-brand-600 hover:bg-brand-700" };
    }
    if (order.isPaid && (order.status === "completed" || order.status === "partially_refunded")) {
      return { label: "Refund", className: "bg-red-600 hover:bg-red-700" };
    }
    return { label: "Reprint Kitchen", className: "bg-stone-500 hover:bg-stone-600" };
  }

  if (order.type === "delivery") {
    if (!order.isPaid) {
      if (order.status === "preparing") return { label: "Ready", className: "bg-orange-600 hover:bg-orange-700" };
      if (order.status === "ready") return { label: "Dispatch", className: "bg-brand-600 hover:bg-brand-700" };
      if (order.status === "dispatched") return { label: "Completed", className: "bg-brand-600 hover:bg-brand-700" };
      if (order.status === "completed") return { label: "Take Payment", className: "bg-brand-600 hover:bg-brand-700" };
    }
    if (order.isPaid && (order.status === "completed" || order.status === "partially_refunded")) {
      return { label: "Refund", className: "bg-red-600 hover:bg-red-700" };
    }
    return { label: "Reprint Kitchen", className: "bg-stone-500 hover:bg-stone-600" };
  }

  return { label: "Reprint Kitchen", className: "bg-stone-500 hover:bg-stone-600" };
}

export default function CockpitBoard({ initialOrders }: { initialOrders: CockpitOrder[] }) {
  const router = useRouter();
  const { isFullscreen, toggleFullscreen } = useFullscreen();
  const [activeTab, setActiveTab] = useState<OrderType>("dine_in");
  const [orders, setOrders] = useState<CockpitOrder[]>(initialOrders);
  const [riders, setRiders] = useState<RiderOption[]>([]);
  const [riderModalFor, setRiderModalFor] = useState<string | null>(null);
  const [voidModalFor, setVoidModalFor] = useState<string | null>(null);
  const [voidReason, setVoidReason] = useState("");
  const [refundModalFor, setRefundModalFor] = useState<string | null>(null);
  const [refundReason, setRefundReason] = useState("");
  const [refundType, setRefundType] = useState<"full" | "partial_items" | "partial_custom">("full");
  const [partialItems, setPartialItems] = useState<Record<number, number>>({});
  const [partialCustomAmount, setPartialCustomAmount] = useState("");
  const [deliveryReadyFor, setDeliveryReadyFor] = useState<CockpitOrder | null>(null);
  const [completeOrder, setCompleteOrder] = useState<CockpitOrder | null>(null);
  const [completePaymentMethod, setCompletePaymentMethod] = useState<string>("cash");
  const [completeSubmitting, setCompleteSubmitting] = useState(false);
  const [refundOrderItems, setRefundOrderItems] = useState<Array<{ name: string; price: number; qty: number; maxRefundable: number }>>([]);
  const [shiftOpen, setShiftOpen] = useState(false);
  const [shiftLoaded, setShiftLoaded] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tab = params.get("tab");
    if (tab === "dine_in" || tab === "takeaway" || tab === "delivery") setActiveTab(tab);
  }, []);

  // Track shift status here too — new orders require an open shift.
  const loadShiftStatus = useCallback(async () => {
    try {
      const res = await fetch("/api/shifts?current=1");
      if (!res.ok) return;
      const data = await res.json();
      setShiftOpen(Boolean(data.shifts?.[0]?.isOpen));
    } catch {
      /* offline-safe: leave as-is */
    } finally {
      setShiftLoaded(true);
    }
  }, []);

  useEffect(() => {
    loadShiftStatus();
    const id = setInterval(loadShiftStatus, 15000);
    return () => clearInterval(id);
  }, [loadShiftStatus]);

  // Live board — poll the real API.
  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/orders");
      if (res.ok) setOrders(await res.json());
    } catch {
      /* keep last known state */
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, [refresh]);

  useEffect(() => {
    fetch("/api/staff?role=rider")
      .then((r) => (r.ok ? r.json() : []))
      .then(setRiders)
      .catch(() => setRiders([]));
  }, []);

  async function patchOrder(orderId: string, body: Record<string, unknown>): Promise<boolean> {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(data.error || "Request failed");
        return false;
      }
      refresh();
      return true;
    } catch {
      toast.error("Cannot reach the server");
      return false;
    }
  }

  async function assignRider(orderId: string, riderId: string) {
    if (await patchOrder(orderId, { riderId })) {
      toast.success("Rider assigned");
      setRiderModalFor(null);
    }
  }

  async function voidOrder(orderId: string) {
    if (!voidReason.trim()) return;
    if (await patchOrder(orderId, { voidReason: voidReason.trim() })) {
      toast.warning("Order voided");
      setVoidModalFor(null);
      setVoidReason("");
    }
  }

  function loadRefundOrderDetails(order: CockpitOrder) {
    setRefundOrderItems(
      (order.items || []).map((item) => ({
        name: item.name,
        price: item.price,
        qty: item.qty,
        maxRefundable: item.qty - (item.qtyRefunded ?? 0),
      }))
    );
  }

  async function processRefund(order: CockpitOrder) {
    if (!refundReason.trim()) {
      toast.error("Refund reason required");
      return;
    }
    const refund: Record<string, unknown> = {
      reason: refundReason.trim(),
      refundMethod: order.paymentMethod || "cash",
    };
    if (refundType === "full") {
      refund.isFullRefund = true;
    } else if (refundType === "partial_items") {
      const items = Object.entries(partialItems)
        .map(([k, v]) => ({ orderItemIndex: Number(k), qtyRefunded: v }))
        .filter((i) => i.qtyRefunded > 0);
      if (items.length === 0) {
        toast.error("Select at least one item to refund");
        return;
      }
      refund.items = items;
    } else {
      const amt = Number(partialCustomAmount);
      if (!(amt > 0)) {
        toast.error("Enter a refund amount");
        return;
      }
      refund.customAmount = amt;
    }

    if (await patchOrder(order._id, { refund })) {
      toast.success("Refund processed");
      setRefundModalFor(null);
      setRefundReason("");
      setRefundType("full");
      setPartialItems({});
      setPartialCustomAmount("");
      setRefundOrderItems([]);
    }
  }

  async function printTicket(order: CockpitOrder, type: "kitchen" | "receipt") {
    try {
      const res = await fetch(`/api/orders/${order._id}/print`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.success) {
        toast.success(type === "kitchen" ? "Kitchen ticket printed" : "Receipt printed");
      } else {
        toast.error(type === "kitchen" ? "Kitchen ticket failed" : "Receipt failed", {
          description: data.error || "Check printer connection",
        });
      }
    } catch {
      toast.error("Print failed", { description: "Cannot reach the server" });
    }
  }

  async function confirmComplete() {
    if (!completeOrder) return;
    setCompleteSubmitting(true);
    const ok = await patchOrder(completeOrder._id, {
      pay: { method: completePaymentMethod, amount: completeOrder.total },
    });
    setCompleteSubmitting(false);
    if (!ok) return;

    const wasUnpaid = !completeOrder.isPaid;
    toast.success(wasUnpaid ? "Order completed & paid" : "Order completed");
    setCompleteOrder(null);

    // Dine In / Takeaway: receipt prints on Complete & Pay. Delivery's
    // receipt is printed from the Ready-for-Dispatch popup instead.
    if (completeOrder.type !== "delivery") {
      printTicket(completeOrder, "receipt");
    }
  }

  async function handleAction(order: CockpitOrder) {
    const action = actionFor(order);

    if (action.label === "Ready") {
      if (order.type === "delivery") {
        if (await patchOrder(order._id, { status: "ready" })) {
          setDeliveryReadyFor(order);
        }
      } else {
        if (await patchOrder(order._id, { status: "ready" })) {
          toast.info("Order ready", { description: `${order.orderNumber} moved to ready` });
        }
      }
    } else if (action.label === "Dispatch") {
      if (await patchOrder(order._id, { status: "dispatched" })) {
        toast.info("Order dispatched", { description: `${order.orderNumber} sent to rider` });
      }
    } else if (action.label === "Completed" || action.label === "Cash Out" || action.label === "Take Payment") {
      if (!order.isPaid) {
        setCompleteOrder(order);
        setCompletePaymentMethod("cash");
        setCompleteSubmitting(false);
      } else {
        toast.info("Order is already paid");
      }
    } else if (action.label === "Reprint Kitchen") {
      printTicket(order, "kitchen");
    } else if (action.label === "Refund") {
      setRefundModalFor(order._id);
      setRefundType("full");
      setPartialItems({});
      setPartialCustomAmount("");
      setRefundReason("");
      loadRefundOrderDetails(order);
    }
  }

  const isTerminalOrder = (order: CockpitOrder) =>
    order.status === "cancelled" ||
    order.status === "refunded" ||
    (order.isPaid && (order.status === "completed" || order.status === "partially_refunded"));

  const counts = useMemo(() => {
    const c: Record<OrderType, number> = { dine_in: 0, takeaway: 0, delivery: 0 };
    for (const o of orders) if (!isTerminalOrder(o)) c[o.type]++;
    return c;
  }, [orders]);

  const visibleOrders = orders.filter((o) => o.type === activeTab && !isTerminalOrder(o));

  return (
    <div className="flex flex-col h-full bg-stone-100">
      <ShiftBar />

      {/* Header */}
      <div className="px-6 py-3 bg-white border-b border-stone-200 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-lg font-semibold text-stone-900 font-brand">POS Cockpit</h1>
          <p className="text-xs text-stone-500 mt-0.5">
            {counts[activeTab]} active {activeTab === "dine_in" ? "tables" : activeTab === "takeaway" ? "orders" : "deliveries"}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {QUICK_ORDER_TYPES.map((qt) => (
            <button
              key={qt.type}
              data-testid={`new-order-${qt.type}`}
              onClick={() => {
                if (!shiftOpen) {
                  toast.info("Please start your shift before creating an order.", {
                    description: "Use the Start Shift button in the bar above.",
                    position: "top-center",
                  });
                  window.dispatchEvent(new Event("shift:start-required"));
                  return;
                }
                router.push(`/pos/order/new?type=${qt.type}`);
              }}
              className={`flex flex-col items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                shiftLoaded && shiftOpen
                  ? "bg-brand-600 hover:bg-brand-700 text-white cursor-pointer"
                  : "bg-stone-200 text-stone-400 cursor-not-allowed hover:bg-stone-200"
              }`}
              title={shiftLoaded && !shiftOpen ? "Start a shift first" : `New ${qt.label} order`}
            >
              <qt.icon className="w-4 h-4" />
              <span className="hidden sm:inline leading-none">{qt.label}</span>
            </button>
          ))}

          <button
            onClick={() => router.push("/dashboard")}
            title="Dashboard"
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-stone-100 text-stone-600 text-sm font-medium hover:bg-stone-200 transition-colors"
          >
            <LayoutGrid className="w-4 h-4" />
          </button>

          <button
            onClick={toggleFullscreen}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-stone-100 text-stone-600 text-sm font-medium hover:bg-stone-200 transition-colors"
            title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          <button
            onClick={async () => {
              try { await fetch("/api/auth/logout", { method: "POST" }); } catch { /* noop */ }
              router.push("/login");
              router.refresh();
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-stone-100 text-stone-700 text-sm font-medium hover:bg-stone-200 transition-colors"
            title="Log out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex border-b border-stone-200 bg-white">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            data-testid={`cockpit-tab-${tab.key}`}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-1 py-3 px-4 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
              activeTab === tab.key
                ? "bg-brand-600 text-white"
                : "bg-white text-stone-600 hover:bg-stone-50"
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
            <span className={`ml-1 px-1.5 py-0.5 rounded-full text-xs ${
              activeTab === tab.key ? "bg-white/20" : "bg-stone-100 text-stone-500"
            }`}>
              {counts[tab.key]}
            </span>
          </button>
        ))}
      </div>

      {/* Orders table */}
      <div className="flex-1 overflow-auto px-6 py-4">
        <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="text-xs text-stone-500 uppercase tracking-wider bg-stone-50 border-b border-stone-200">
                  <th className="py-3 px-4 font-medium">Order #</th>
                  <th className="py-3 px-4 font-medium">Time</th>
                  {activeTab === "dine_in" && <th className="py-3 px-4 font-medium">Table</th>}
                  <th className="py-3 px-4 font-medium">Customer</th>
                  {activeTab === "dine_in" && <th className="py-3 px-4 font-medium">Waiter</th>}
                  {activeTab === "delivery" && <th className="py-3 px-4 font-medium">Rider</th>}
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 font-medium text-right">Amount</th>
                  <th className="py-3 px-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {visibleOrders.map((order) => {
                  const action = actionFor(order);
                  return (
                    <tr key={order._id} className="border-b border-stone-100 hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-4 font-semibold text-brand-700 tabular">{order.orderNumber}</td>
                      <td className="py-3 px-4 text-stone-500 tabular">
                        {new Date(order.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </td>
                      {activeTab === "dine_in" && (
                        <td className="py-3 px-4 font-medium text-stone-900 tabular">{order.table || "—"}</td>
                      )}
                      <td className="py-3 px-4 font-medium text-stone-900">
                        {order.customer?.name || order.customer?.phone || "Guest"}
                      </td>
                      {activeTab === "dine_in" && (
                        <td className="py-3 px-4 text-stone-500">
                          {order.waiter?.name || <span className="text-stone-300">—</span>}
                        </td>
                      )}
                      {activeTab === "delivery" && (
                        <td className="py-3 px-4">
                          {order.rider?.name ? (
                            <span className="text-stone-900 font-medium">{order.rider.name}</span>
                          ) : (
                            <button
                              onClick={() => setRiderModalFor(order._id)}
                              className="text-brand-700 text-sm hover:underline font-medium"
                            >
                              Set Rider
                            </button>
                          )}
                        </td>
                      )}
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_STYLES[order.status] || "bg-stone-100 text-stone-600"}`}>
                          {order.status.replace(/_/g, " ")}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-semibold text-stone-900 tabular">
                        Rs. {order.total.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleAction(order)}
                            className={`px-3 py-1.5 rounded-lg text-white text-xs font-medium ${action.className} transition-colors`}
                          >
                            {action.label}
                          </button>
                          <button
                            onClick={() => printTicket(order, "receipt")}
                            title="Print Receipt"
                            className="px-2 py-1 rounded text-xs font-medium bg-stone-100 text-stone-600 hover:bg-stone-200 transition-colors"
                          >
                            Receipt
                          </button>
                          {order.isPaid && (order.status === "completed" || order.status === "partially_refunded") && (
                            <button
                              onClick={() => {
                                setRefundModalFor(order._id);
                                setRefundType("full");
                                setPartialItems({});
                                setPartialCustomAmount("");
                                setRefundReason("");
                                loadRefundOrderDetails(order);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-medium hover:bg-red-700 transition-colors"
                            >
                              Refund
                            </button>
                          )}
                          <button
                            onClick={() => printTicket(order, "kitchen")}
                            title="Print Kitchen Ticket"
                            className="px-2 py-1 rounded text-xs font-medium bg-stone-100 text-stone-600 hover:bg-stone-200 transition-colors"
                          >
                            Kitchen
                          </button>
                          {!order.isPaid && order.status !== "cancelled" && (
                            <button
                              onClick={() => setVoidModalFor(order._id)}
                              className="text-red-600 text-xs hover:underline font-medium"
                            >
                              Void
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {visibleOrders.length === 0 && (
                  <tr>
                    <td colSpan={activeTab === "dine_in" ? 8 : activeTab === "delivery" ? 7 : 6} className="py-12 text-center text-stone-400">
                      No active {activeTab === "dine_in" ? "tables" : activeTab === "takeaway" ? "orders" : "deliveries"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Rider Dialog */}
      <Dialog open={riderModalFor !== null} onOpenChange={(open) => { if (!open) setRiderModalFor(null); }}>
        <DialogContent className="sm:max-w-[320px]">
          <DialogHeader><DialogTitle>Set Rider</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-2 py-2">
            {riders.map((r) => (
              <button
                key={r._id}
                onClick={() => riderModalFor && assignRider(riderModalFor, r._id)}
                className="w-full text-left px-4 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
              >
                {r.name}
              </button>
            ))}
            {riders.length === 0 && (
              <p className="text-sm text-stone-500 py-2">No riders added yet — add one in Admin → Staff.</p>
            )}
          </div>
          <DialogFooter>
            <button onClick={() => setRiderModalFor(null)} className="btn-secondary">Cancel</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Void Dialog */}
      <Dialog open={voidModalFor !== null} onOpenChange={(open) => { if (!open) { setVoidModalFor(null); setVoidReason(""); } }}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader><DialogTitle>Void Order</DialogTitle></DialogHeader>
          <p className="text-sm text-stone-600 py-2">
            This cancels the order. It stays in the system for audit purposes but leaves the active board.
          </p>
          <div className="space-y-2">
            <label className="text-xs text-stone-500">Reason (required)</label>
            <textarea
              value={voidReason}
              onChange={(e) => setVoidReason(e.target.value)}
              placeholder="Enter reason for voiding..."
              rows={3}
              className="input"
            />
          </div>
          <DialogFooter>
            <button onClick={() => { setVoidModalFor(null); setVoidReason(""); }} className="btn-secondary">Cancel</button>
            <button onClick={() => voidModalFor && voidOrder(voidModalFor)} disabled={!voidReason.trim()} className="btn-danger">
              Void Order
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Refund Dialog */}
      <Dialog open={refundModalFor !== null} onOpenChange={(open) => { if (!open) { setRefundModalFor(null); setRefundReason(""); } }}>
        <DialogContent className="sm:max-w-[480px] max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Refund Order</DialogTitle></DialogHeader>
          <p className="text-sm text-stone-600">
            Process a refund for this paid order. Select refund type and provide a reason.
          </p>
          <div className="space-y-2 py-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="refundType" checked={refundType === "full"} onChange={() => setRefundType("full")} className="text-brand-600" />
              <span className="text-sm text-stone-700">Full Refund (entire order amount)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="refundType" checked={refundType === "partial_items"} onChange={() => setRefundType("partial_items")} className="text-brand-600" />
              <span className="text-sm text-stone-700">Partial Refund — Select Items</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="radio" name="refundType" checked={refundType === "partial_custom"} onChange={() => setRefundType("partial_custom")} className="text-brand-600" />
              <span className="text-sm text-stone-700">Partial Refund — Custom Amount</span>
            </label>
          </div>

          {refundType === "partial_items" && (
            <div className="mb-4 p-3 bg-stone-50 rounded-lg max-h-48 overflow-y-auto">
              <p className="text-xs text-stone-500 mb-2">Set quantity to refund for each item:</p>
              {refundOrderItems.length === 0 ? (
                <p className="text-sm text-stone-500">No refundable items</p>
              ) : (
                <div className="space-y-2">
                  {refundOrderItems.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-white rounded border">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-stone-900 truncate">{item.name}</p>
                        <p className="text-xs text-stone-500">
                          Rs. {item.price.toFixed(2)} each · {item.maxRefundable} available
                        </p>
                      </div>
                      <div className="flex items-center gap-1 ml-2">
                        <button
                          onClick={() => { const c = partialItems[index] ?? 0; if (c > 0) setPartialItems({ ...partialItems, [index]: c - 1 }); }}
                          disabled={!(partialItems[index] > 0)}
                          className="w-7 h-7 rounded border border-stone-300 text-stone-700 hover:bg-stone-100 disabled:opacity-40 text-sm font-medium"
                        >−</button>
                        <span className="w-8 text-center text-sm font-medium tabular">{partialItems[index] ?? 0}</span>
                        <button
                          onClick={() => { const c = partialItems[index] ?? 0; if (c < item.maxRefundable) setPartialItems({ ...partialItems, [index]: c + 1 }); }}
                          disabled={!((partialItems[index] ?? 0) < item.maxRefundable)}
                          className="w-7 h-7 rounded border border-stone-300 text-stone-700 hover:bg-stone-100 disabled:opacity-40 text-sm font-medium"
                        >+</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {refundType === "partial_custom" && (
            <div className="mb-4">
              <label className="text-xs text-stone-500 block mb-1">Custom Refund Amount (Rs.)</label>
              <input type="number" step="0.01" min="0" value={partialCustomAmount} onChange={(e) => setPartialCustomAmount(e.target.value)} className="input" placeholder="Enter custom amount" />
            </div>
          )}

          <div className="mb-2">
            <label className="text-xs text-stone-500 block mb-1">Reason (required)</label>
            <textarea value={refundReason} onChange={(e) => setRefundReason(e.target.value)} placeholder="Enter reason for refund..." rows={2} className="input" />
          </div>

          <DialogFooter>
            <button
              onClick={() => { setRefundModalFor(null); setRefundReason(""); setRefundType("full"); setPartialItems({}); setPartialCustomAmount(""); }}
              className="btn-secondary"
            >Cancel</button>
            <button
              onClick={() => refundModalFor && processRefund({ _id: refundModalFor } as CockpitOrder)}
              disabled={!refundReason.trim()}
              className="btn-danger"
            >Process Refund</button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Complete Dialog */}
      <Dialog open={completeOrder !== null} onOpenChange={(open) => { if (!open) setCompleteOrder(null); }}>
        <DialogContent className="sm:max-w-[520px] max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Complete Order</DialogTitle></DialogHeader>
          {completeOrder && (
            <>
              <p className="text-sm text-stone-500">
                {!completeOrder.isPaid
                  ? "Payment has not been recorded — select a method to complete and pay."
                  : "Payment has already been recorded."}
              </p>
              <div className="bg-stone-50 rounded-lg p-3 text-sm space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-stone-500">Order #</span>
                  <span className="font-medium text-stone-900 tabular">{completeOrder.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone-500">Type</span>
                  <span className="font-medium text-stone-900 capitalize">{completeOrder.type.replace("_", " ")}</span>
                </div>
                {completeOrder.type === "dine_in" && (
                  <div className="flex justify-between">
                    <span className="text-stone-500">Table</span>
                    <span className="font-medium text-stone-900">{completeOrder.table || "—"}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-stone-500">Customer</span>
                  <span className="font-medium text-stone-900">{completeOrder.customer?.name || completeOrder.customer?.phone || "Guest"}</span>
                </div>
                {completeOrder.type === "dine_in" && completeOrder.waiter?.name && (
                  <div className="flex justify-between">
                    <span className="text-stone-500">Waiter</span>
                    <span className="font-medium text-stone-900">{completeOrder.waiter.name}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-stone-200 pt-1.5 mt-1.5">
                  <span className="text-stone-500">Payment</span>
                  <span className={`font-medium ${completeOrder.isPaid ? "text-green-700" : "text-amber-600"}`}>
                    {completeOrder.isPaid ? "Received" : "Not yet received"}
                  </span>
                </div>
              </div>

              {(completeOrder.items || []).length > 0 && (
                <div className="mb-2">
                  <p className="text-xs text-stone-500 mb-1.5 font-medium uppercase tracking-wide">Items</p>
                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-stone-50 text-stone-500 text-xs">
                          <th className="text-left py-1.5 px-3 font-medium">Item</th>
                          <th className="text-right py-1.5 px-3 font-medium">Qty</th>
                          <th className="text-right py-1.5 px-3 font-medium">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(completeOrder.items || []).map((item: any, i: number) => (
                          <tr key={i} className="border-t border-stone-100">
                            <td className="py-1.5 px-3 text-stone-900">{item.name}</td>
                            <td className="py-1.5 px-3 text-right text-stone-600 tabular">x{item.qty}</td>
                            <td className="py-1.5 px-3 text-right text-stone-900 font-medium tabular">
                              Rs. {(item.price * item.qty * (1 - (item.lineDiscountPercent || 0) / 100)).toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              <div className="border-t pt-2 mb-3 text-sm space-y-1">
                <div className="flex justify-between text-stone-600">
                  <span>Subtotal</span>
                  <span className="tabular">Rs. {completeOrder.subtotal?.toFixed(2) ?? completeOrder.total.toFixed(2)}</span>
                </div>
                {(completeOrder.discountAmount ?? 0) > 0 && (
                  <div className="flex justify-between text-stone-600">
                    <span>Discount ({completeOrder.discountPercent ?? 0}%)</span>
                    <span className="tabular">-Rs. {completeOrder.discountAmount?.toFixed(2)}</span>
                  </div>
                )}
                {(completeOrder.deliveryCharges ?? 0) > 0 && (
                  <div className="flex justify-between text-stone-600">
                    <span>Delivery</span>
                    <span className="tabular">Rs. {completeOrder.deliveryCharges?.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-semibold text-stone-900 text-base border-t pt-1.5">
                  <span>Total</span>
                  <span className="tabular">Rs. {completeOrder.total.toFixed(2)}</span>
                </div>
              </div>

              {!completeOrder.isPaid && (
                <div className="mb-3">
                  <p className="text-xs text-stone-500 mb-2 font-medium uppercase tracking-wide">Payment Method</p>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { key: "cash", label: "Cash" },
                      { key: "easypaisa", label: "EasyPaisa" },
                      { key: "jazzcash", label: "JazzCash" },
                      { key: "card", label: "Card" },
                      { key: "bank", label: "Bank Transfer" },
                    ].map((m) => (
                      <button
                        key={m.key}
                        onClick={() => setCompletePaymentMethod(m.key)}
                        className={`py-2.5 rounded-lg font-medium text-sm border transition-colors ${
                          completePaymentMethod === m.key
                            ? "bg-brand-600 text-white border-brand-600"
                            : "bg-white text-stone-700 border-stone-300 hover:bg-stone-50"
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          <DialogFooter>
            <button onClick={() => setCompleteOrder(null)} className="btn-secondary">Cancel</button>
            <button onClick={confirmComplete} disabled={completeSubmitting} className="btn-primary">
              {completeSubmitting ? "Completing…" : !completeOrder?.isPaid ? "Complete & Pay" : "Confirm Complete"}
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delivery Ready Dialog */}
      <Dialog open={deliveryReadyFor !== null} onOpenChange={(open) => { if (!open) { setDeliveryReadyFor(null); refresh(); } }}>
        <DialogContent className="sm:max-w-[520px] max-h-[85vh] overflow-y-auto">
          <DeliveryReadyPopup
            order={deliveryReadyFor as any}
            onClose={() => { setDeliveryReadyFor(null); refresh(); }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
