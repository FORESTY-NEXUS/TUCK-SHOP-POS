"use client";

import { useMemo, useState } from "react";
import { toast } from "sonner";

type Variant = { name: string; price: number };
type Category = { _id: string; name: string; sortOrder: number };
type Product = {
  _id: string;
  name: string;
  price: number;
  category: Category | string;
  cost?: number;
  isAvailable?: boolean;
  hasVariants?: boolean;
  variants?: Variant[];
};

export default function ProductManager({
  initialProducts,
  initialCategories,
}: {
  initialProducts: Product[];
  initialCategories: Category[];
}) {
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [categories, setCategories] = useState<Category[]>(initialCategories);

  // Add form
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [hasVariants, setHasVariants] = useState(false);
  const [newVariants, setNewVariants] = useState<Variant[]>([]);
  const [newCategoryName, setNewCategoryName] = useState("");

  // Edit form
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editName, setEditName] = useState("");
  const [editPrice, setEditPrice] = useState("");
  const [editCategoryId, setEditCategoryId] = useState("");
  const [editHasVariants, setEditHasVariants] = useState(false);
  const [editCost, setEditCost] = useState("");
  const [editIsAvailable, setEditIsAvailable] = useState(true);
  const [editVariantInputs, setEditVariantInputs] = useState<Variant[]>([]);

  async function refresh() {
    try {
      const res = await fetch("/api/products?all=1");
      if (res.ok) setProducts(await res.json());
      const cRes = await fetch("/api/categories");
      if (cRes.ok) setCategories(await cRes.json());
    } catch { /* keep */ }
  }

  function catName(cat: Category | string): string {
    return typeof cat === "object" ? cat.name : (categories.find((c) => c._id === cat)?.name || cat);
  }

  function openEdit(p: Product) {
    setEditingProduct(p);
    setEditName(p.name);
    setEditPrice(String(p.price));
    setEditCategoryId(typeof p.category === "object" ? p.category._id : p.category);
    setEditHasVariants(p.hasVariants || false);
    setEditCost(p.cost != null ? String(p.cost) : "");
    setEditIsAvailable(p.isAvailable !== false);
    setEditVariantInputs(p.variants || []);
  }

  async function addProduct() {
    if (!name.trim() || (!hasVariants && !price)) return;
    let cid = categoryId;
    if (!cid && newCategoryName.trim()) {
      const catRes = await fetch("/api/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newCategoryName.trim() }),
      });
      if (!catRes.ok) {
        const d = await catRes.json().catch(() => ({}));
        toast.error(d.error || "Could not create category");
        return;
      }
      const cat = await catRes.json();
      setCategories((prev) => [...prev, cat]);
      setCategoryId(cat._id);
      setNewCategoryName("");
      cid = cat._id;
    }
    if (!cid) return;
    const variants = hasVariants ? newVariants.filter((v) => v.name.trim() && v.price !== undefined) : [];
    const res = await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: name.trim(),
        price: hasVariants ? 0 : Number(price),
        category: cid,
        hasVariants,
        variants: variants.map((v) => ({ name: v.name.trim(), price: Number(v.price) })),
      }),
    });
    if (res.ok) {
      toast.success("Product added");
      // Keep the category selected so adding several items into one category
      // is fast; name/price/variants reset for the next entry.
      setName(""); setPrice(""); setHasVariants(false); setNewVariants([]);
      await refresh();
    } else {
      const d = await res.json().catch(() => ({}));
      toast.error(d.error || "Failed to add product");
    }
  }

  async function saveEdit() {
    if (!editingProduct || !editName.trim() || !editCategoryId) return;
    const variants = editHasVariants ? editVariantInputs.filter((v) => v.name.trim()) : [];
    const res = await fetch(`/api/products/${editingProduct._id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: editName.trim(),
        price: editHasVariants ? 0 : Number(editPrice),
        category: editCategoryId,
        cost: editCost ? Number(editCost) : 0,
        isAvailable: editIsAvailable,
        hasVariants: editHasVariants,
        variants: variants.map((v) => ({ name: v.name.trim(), price: Number(v.price) })),
      }),
    });
    if (res.ok) {
      toast.success("Product updated");
      setEditingProduct(null);
      setEditVariantInputs([]);
      await refresh();
    } else {
      const d = await res.json().catch(() => ({}));
      toast.error(d.error || "Failed to save product");
    }
  }

  async function removeProduct(id: string, name?: string) {
    if (!confirm(`Permanently delete "${name || "this product"}"? Past orders keep their own copies.`)) return;
    const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
    if (res.ok) {
      toast.success("Product deleted");
      await refresh();
    } else {
      toast.error("Failed to delete product");
    }
  }

  async function addNewCategory() {
    if (!newCategoryName.trim()) return;
    const res = await fetch("/api/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newCategoryName.trim() }),
    });
    if (res.ok) {
      const cat = await res.json();
      setCategories((prev) => [...prev, cat]);
      setCategoryId(cat._id);
      setNewCategoryName("");
    } else {
      const d = await res.json().catch(() => ({}));
      toast.error(d.error || "Failed to create category");
    }
  }

  const grouped = useMemo(() => {
    const map = new Map<string, Product[]>();
    for (const p of products) {
      const c = catName(p.category);
      if (!map.has(c)) map.set(c, []);
      map.get(c)!.push(p);
    }
    return map;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [products, categories]);

  function getVariantDisplay(p: Product) {
    if (p.hasVariants && p.variants && p.variants.length) {
      return p.variants.map((v) => `${v.name}: Rs.${v.price}`).join(" · ");
    }
    return `Rs. ${Number(p.price).toFixed(2)}`;
  }

  return (
    <div>
      {/* Add product form */}
      <div className="card p-4 mb-6">
        <h2 className="text-sm font-semibold text-stone-700 uppercase tracking-wide mb-3">Add New Item</h2>
        <div className="flex gap-3 flex-wrap items-end">
          <div className="flex-1 min-w-[160px]">
            <label className="block text-xs text-stone-500 mb-1">Item name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Chicken Tikka Pizza" className="input" onKeyDown={(e) => { if (e.key === "Enter") addProduct(); }} />
          </div>
          {!hasVariants && (
            <div className="w-28">
              <label className="block text-xs text-stone-500 mb-1">Price (Rs.)</label>
              <input value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0.00" type="number" step="0.01" className="input" />
            </div>
          )}
          {hasVariants && (
            <div className="flex-1 min-w-[260px]">
              <label className="block text-xs text-stone-500 mb-1">Variants (size → price)</label>
              <div className="space-y-2">
                {newVariants.map((v, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input value={v.name} onChange={(e) => { const next = [...newVariants]; next[idx] = { ...next[idx], name: e.target.value }; setNewVariants(next); }} placeholder="Size (e.g. Small)" className="input flex-1" />
                    <input value={v.price || ""} onChange={(e) => { const next = [...newVariants]; next[idx] = { ...next[idx], price: Number(e.target.value) }; setNewVariants(next); }} placeholder="Price" type="number" step="0.01" className="input w-24" />
                    <button onClick={() => setNewVariants((prev) => prev.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-600 text-sm">✕</button>
                  </div>
                ))}
                <button onClick={() => setNewVariants((prev) => [...prev, { name: "", price: 0 }])} className="text-sm text-brand-700 hover:text-brand-800 font-medium">+ Add variant</button>
              </div>
            </div>
          )}
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs text-stone-500 mb-1">Category</label>
            <div className="flex gap-2">
              <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className="input flex-1">
                <option value="">Select category</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
              <input value={newCategoryName} onChange={(e) => setNewCategoryName(e.target.value)} placeholder="Or new…" className="input w-32" onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addNewCategory(); } }} />
            </div>
          </div>
          <div className="flex items-center gap-2 pt-6">
            <input type="checkbox" id="hasVariants" checked={hasVariants} onChange={(e) => setHasVariants(e.target.checked)} className="rounded border-stone-300 text-brand-600 focus:ring-brand-500" />
            <label htmlFor="hasVariants" className="text-sm text-stone-700 cursor-pointer select-none">Has Variants?</label>
          </div>
          <button onClick={addProduct} disabled={!name || (!hasVariants && !price) || (!categoryId && !newCategoryName.trim())} className="btn-primary">Add Item</button>
        </div>
      </div>

      {/* Products grouped by category */}
      {Array.from(grouped.entries()).map(([cat, items]) => (
        <div key={cat} className="mb-6">
          <h2 className="text-sm font-semibold text-stone-500 uppercase tracking-wide mb-3">
            {cat} <span className="ml-2 text-xs font-normal text-stone-400">{items.length} item{items.length !== 1 ? "s" : ""}</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {items.map((p) => (
              <div key={p._id} className={`card px-4 py-3 flex justify-between items-center ${p.isAvailable === false ? "opacity-50" : ""}`}>
                <div className="min-w-0">
                  <div className="font-medium text-stone-900 truncate">{p.name}</div>
                  <div className="text-sm text-brand-700 font-semibold mt-0.5 truncate">{getVariantDisplay(p)}</div>
                  {p.hasVariants && <span className="text-xs text-stone-400 mt-0.5 block">Grouped variants</span>}
                  {p.isAvailable === false && <span className="text-xs text-red-500 block">Unavailable</span>}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => openEdit(p)} className="text-brand-700 hover:text-brand-800 text-sm font-medium">Edit</button>
                  <button onClick={() => removeProduct(p._id, p.name)} className="text-red-400 hover:text-red-600 text-sm font-medium">Remove</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {products.length === 0 && (
        <div className="text-center py-16 card border-dashed"><p className="text-stone-400 text-sm">No products yet. Add one above.</p></div>
      )}

      {/* Edit modal */}
      {editingProduct && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 max-h-[90vh] overflow-y-auto">
            <div className="px-5 py-4 border-b border-stone-200"><h2 className="font-semibold text-stone-900">Edit Product</h2></div>
            <div className="px-5 py-4 space-y-3">
              <div>
                <label className="block text-xs text-stone-500 mb-1">Item name</label>
                <input value={editName} onChange={(e) => setEditName(e.target.value)} className="input" />
              </div>
              {!editHasVariants && (
                <div className="w-28">
                  <label className="block text-xs text-stone-500 mb-1">Price (Rs.)</label>
                  <input value={editPrice} onChange={(e) => setEditPrice(e.target.value)} type="number" step="0.01" className="input" />
                </div>
              )}
              {editHasVariants && (
                <div>
                  <label className="block text-xs text-stone-500 mb-1">Variants</label>
                  <div className="space-y-2">
                    {editVariantInputs.map((v, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input value={v.name} onChange={(e) => { const next = [...editVariantInputs]; next[idx] = { ...next[idx], name: e.target.value }; setEditVariantInputs(next); }} placeholder="Size" className="input flex-1" />
                        <input value={v.price || ""} onChange={(e) => { const next = [...editVariantInputs]; next[idx] = { ...next[idx], price: Number(e.target.value) }; setEditVariantInputs(next); }} placeholder="Price" type="number" step="0.01" className="input w-24" />
                        <button onClick={() => setEditVariantInputs((prev) => prev.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-600 text-sm">✕</button>
                      </div>
                    ))}
                    <button onClick={() => setEditVariantInputs((prev) => [...prev, { name: "", price: 0 }])} className="text-sm text-brand-700 hover:text-brand-800 font-medium">+ Add variant</button>
                  </div>
                </div>
              )}
              <div>
                <label className="block text-xs text-stone-500 mb-1">Category</label>
                <select value={editCategoryId} onChange={(e) => setEditCategoryId(e.target.value)} className="input">
                  <option value="">Select category</option>
                  {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
                </select>
              </div>
              <div className="flex gap-6 items-center">
                <div className="w-28">
                  <label className="block text-xs text-stone-500 mb-1">Cost (Rs.)</label>
                  <input value={editCost} onChange={(e) => setEditCost(e.target.value)} type="number" step="0.01" placeholder="0.00" className="input" />
                </div>
                <label className="flex items-center gap-2 text-sm text-stone-700 cursor-pointer select-none">
                  <input type="checkbox" checked={editIsAvailable} onChange={(e) => setEditIsAvailable(e.target.checked)} className="rounded border-stone-300 text-brand-600 focus:ring-brand-500" />
                  Available
                </label>
                <label className="flex items-center gap-2 text-sm text-stone-700 cursor-pointer select-none">
                  <input type="checkbox" checked={editHasVariants} onChange={(e) => { setEditHasVariants(e.target.checked); if (!e.target.checked) setEditVariantInputs([]); }} className="rounded border-stone-300 text-brand-600 focus:ring-brand-500" />
                  Has Variants
                </label>
              </div>
            </div>
            <div className="px-5 py-4 border-t border-stone-200 flex gap-3 justify-end">
              <button onClick={() => { setEditingProduct(null); setEditVariantInputs([]); }} className="btn-secondary">Cancel</button>
              <button onClick={saveEdit} disabled={!editName || (!editHasVariants && !editPrice) || !editCategoryId} className="btn-primary">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
