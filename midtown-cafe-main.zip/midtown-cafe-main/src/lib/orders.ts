import { connectDB } from "@/lib/db";
import { Order } from "@/models/Order";
// Import Customer to ensure model is registered before populate()
import "@/models/Customer";

// Used directly by Server Components for the initial SSR paint of the
// Cockpit. The client then talks to /api/orders for live refreshes.
export async function getActiveOrders() {
  await connectDB();
  const orders = await Order.find({ status: { $nin: ["completed", "cancelled"] } })
    .sort({ createdAt: -1 })
    .populate("customer", "name phone loyaltyPoints")
    .populate("waiter", "name")
    .populate("rider", "name")
    .lean();

  // Serialize ObjectIds/Dates for passing from Server -> Client component.
  return JSON.parse(JSON.stringify(orders));
}
