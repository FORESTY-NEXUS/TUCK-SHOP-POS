import { Schema, model, models, InferSchemaType } from "mongoose";

const CustomerSchema = new Schema(
  {
    name: { type: String, trim: true },
    phone: { type: String, required: true, unique: true, index: true },
    loyaltyPoints: { type: Number, default: 0 },
    // Delivery convenience: last-used address, shown as a default next time.
    lastAddress: { type: String, trim: true },
  },
  { timestamps: true }
);

export type CustomerDoc = InferSchemaType<typeof CustomerSchema>;

// Shared "Guest" / walk-in record. Cashiers use this one-tap escape hatch
// when a walk-in customer refuses to give a name or phone. Because it is a
// single shared record, it must NOT accumulate real loyalty points — there is
// no real person to redeem them. Order payment skips point accrual when the
// linked customer's phone matches GUEST_PHONE.
export const GUEST_PHONE = "0000000000";
export const GUEST_NAME = "Guest";

export const Customer = models.Customer || model("Customer", CustomerSchema);
