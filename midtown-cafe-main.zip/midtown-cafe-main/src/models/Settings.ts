import { Schema, model, models } from "mongoose";

const SettingsSchema = new Schema(
  {
    // How many rupees spent = 1 loyalty point
    // e.g. 100 means customer earns 1 point per Rs. 100 spent
    rupeesPerPoint: { type: Number, required: true, default: 100, min: 1 },

    // Thermal printer settings (Windows printer queue name)
    printerName: { type: String, default: "" },       // Exact Windows printer queue name
    printerType: { type: String, default: "EPSON" },  // EPSON, STAR, etc.
    paperWidth: { type: Number, default: 48 },        // Columns: 32/48 (58mm) or 48/64 (80mm)
    autoCut: { type: Boolean, default: true },        // Cut paper after print

    // Delivery address auto-fill from customer's lastAddress
    // Default ON for convenience
    autoFillDeliveryAddress: { type: Boolean, default: true },

    // Speed Dial: 10 slots (0-9) mapping to product IDs
    // Only active in OrderBuilder cart/item screen
    speedDial: {
      type: Map,
      of: String, // productId as string
      default: {},
    },

    // Store branding
    storeName: { type: String, default: "" },
    storeAddress: { type: String, default: "" },
    storePhone: { type: String, default: "" },
  // About Us / help & support contact — edited on the About Us page. This is
  // deliberately separate from the store contact above: support/help is a
  // different concept and must never silently override storePhone.
    posDisplayLogo: { type: String, default: "" },   // base64 data URL
    receiptLogo: { type: String, default: "" },       // base64 data URL
  },
  { timestamps: true }
);

// Singleton pattern: only one settings document
export const Settings = models.Settings || model("Settings", SettingsSchema);
