import { Schema, model, models, Types } from "mongoose";

const RefundItemSchema = new Schema(
  {
    // Reference to the original order item (by index or _id)
    orderItemIndex: { type: Number, required: true },
    productName: { type: String, required: true },
    price: { type: Number, required: true },
    qty: { type: Number, required: true, min: 1 },
    lineDiscountPercent: { type: Number, default: 0 },
    // If partial qty refunded (e.g., 1 of 3 burgers)
    qtyRefunded: { type: Number, required: true, min: 1 },
    // Refund amount for this specific item line
    amount: { type: Number, required: true, min: 0 },
  },
  { _id: false }
);

const RefundSchema = new Schema(
  {
    order: { type: Schema.Types.ObjectId, ref: "Order", required: true, index: true },
    shift: { type: Schema.Types.ObjectId, ref: "Shift", required: true, index: true },
    // Staff member who processed the refund
    staff: { type: Schema.Types.ObjectId, ref: "Staff", required: true },
    // Total amount refunded
    amount: { type: Number, required: true, min: 0 },
    // Payment method the refund was issued to (same as original or cash for everything)
    refundMethod: { type: String, enum: ["cash", "easypaisa", "jazzcash", "card", "bank"], required: true },
    // Whether this is a full refund of the entire order
    isFullRefund: { type: Boolean, default: false },
    // Items refunded (empty array for full refund, populated for partial)
    items: { type: [RefundItemSchema], default: [] },
    // Custom amount for partial refunds that don't map to items
    customAmount: { type: Number, min: 0 },
    // Required reason (same pattern as void)
    reason: { type: String, required: true, trim: true },
    // Timestamp
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

RefundSchema.index({ order: 1, createdAt: -1 });
RefundSchema.index({ shift: 1, createdAt: -1 });

export type RefundItem = {
  orderItemIndex: number;
  productName: string;
  price: number;
  qty: number;
  lineDiscountPercent?: number;
  qtyRefunded: number;
  amount: number;
};

export const Refund = models.Refund || model("Refund", RefundSchema);