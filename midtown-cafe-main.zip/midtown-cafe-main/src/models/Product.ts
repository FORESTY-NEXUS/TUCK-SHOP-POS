import { Schema, model, models, InferSchemaType, Types } from "mongoose";

// Variants: products like sizes (Half/Full, Small/Medium/Large/Family) use
// one Product document with a `variants` array. On the order screen a click
// on a variant product opens a picker instead of adding the base line.
const VariantSchema = new Schema(
  {
    name: { type: String, required: true, trim: true },
    price: { type: Number, required: true, min: 0 },
  },
  { _id: false }
);

const ProductSchema = new Schema(
  {
    name: { type: String, required: true, trim: true },
    price: { type: Number, required: true, min: 0 },
    category: { type: Schema.Types.ObjectId, ref: "Category", required: true, index: true },
    isAvailable: { type: Boolean, default: true },
    // Simple cost field kept for future profit-tracking; not required for v1.
    cost: { type: Number, default: 0 },
    hasVariants: { type: Boolean, default: false },
    variants: { type: [VariantSchema], default: [] },
  },
  { timestamps: true }
);

ProductSchema.index({ name: "text" });

export type ProductDoc = InferSchemaType<typeof ProductSchema>;

export const Product = models.Product || model("Product", ProductSchema);
