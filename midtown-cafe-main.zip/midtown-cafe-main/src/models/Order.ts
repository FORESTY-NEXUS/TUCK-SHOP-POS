import { Schema, model, models, Types } from "mongoose";

export const ORDER_TYPES = ["dine_in", "takeaway", "delivery"] as const;
export type OrderType = (typeof ORDER_TYPES)[number];

// Status is the single field the Cockpit action button reacts to.
// "refunded" = full refund, "partially_refunded" = partial refund
export const ORDER_STATUSES = [
  "preparing",
  "ready",
  "dispatched", // delivery only
  "completed",
  "cancelled",
  "refunded",
  "partially_refunded",
] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const PAYMENT_METHODS = ["cash", "easypaisa", "jazzcash", "card", "bank"] as const;

const OrderItemSchema = new Schema(
  {
    product: { type: Schema.Types.ObjectId, ref: "Product", required: true },
    name: { type: String, required: true }, // price/name snapshot at time of order
    price: { type: Number, required: true },
    qty: { type: Number, required: true, min: 1 },
    lineDiscountPercent: { type: Number, default: 0 },
    isVoided: { type: Boolean, default: false },
    voidReason: { type: String },
  },
  { _id: true }
);

const OrderSchema = new Schema(
  {
    orderNumber: { type: String, required: true, unique: true, index: true },
    type: { type: String, enum: ORDER_TYPES, required: true },

    // Dine-in specifics
    table: { type: String },
    guests: { type: Number },

    // Delivery / Takeaway specifics
    customer: { type: Schema.Types.ObjectId, ref: "Customer" },
    deliveryAddress: { type: String },
    deliveryCharges: { type: Number, default: 0 },
    rider: { type: Schema.Types.ObjectId, ref: "Staff" },

    waiter: { type: Schema.Types.ObjectId, ref: "Staff" },

    items: { type: [OrderItemSchema], default: [] },

    discountPercent: { type: Number, default: 0 },
    discountAmount: { type: Number, default: 0 },
    note: { type: String },

    subtotal: { type: Number, required: true, default: 0 },
    total: { type: Number, required: true, default: 0 },

    status: { type: String, enum: ORDER_STATUSES, default: "preparing" },

    // Kitchen ticket prints once, immediately on confirmation, for ALL order types.
    kitchenTicketPrinted: { type: Boolean, default: false },
    confirmedAt: { type: Date },

    // Payment: dine-in is paid when the guest leaves (post-meal);
    // delivery/takeaway are paid at order creation (pre-payment).
    isPaid: { type: Boolean, default: false },
    paymentMethod: { type: String, enum: PAYMENT_METHODS },
    paidAt: { type: Date },
    paidAmount: { type: Number },
    shift: { type: Schema.Types.ObjectId, ref: "Shift" }, // set at payment time

    voidReason: { type: String }, // set when the whole order is voided

    // Refund tracking
    refundedAmount: { type: Number, default: 0 }, // total amount refunded across all refunds
    isRefunded: { type: Boolean, default: false }, // true when fully refunded
    // Refunds are tracked in separate Refund model for audit trail
  },
  { timestamps: true }
);

OrderSchema.index({ type: 1, status: 1, createdAt: -1 });

export type OrderItem = {
  product: Types.ObjectId;
  name: string;
  price: number;
  qty: number;
  lineDiscountPercent?: number;
  isVoided?: boolean;
  voidReason?: string;
};

export const Order = models.Order || model("Order", OrderSchema);
